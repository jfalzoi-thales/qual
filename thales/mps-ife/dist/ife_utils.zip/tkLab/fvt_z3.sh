#!/bin/bash

vconsole=/dev/ttyUSB2

stty 115200
stty -F $vconsole 115200


if [ "$1" = "start" ]; then
	echo "S" > $vconsole
elif [ "$1" = "stop" ]; then
	echo "T" > $vconsole
elif [ "$1" = "init" ]; then
	echo "Initializing video encoder module, please wait..."

	echo "T" > $vconsole
	sleep 2

	echo "Y" > $vconsole
	sleep 2

	echo "1" > $vconsole
	sleep 1
	echo "2" > $vconsole
	sleep 2

	echo "2" > $vconsole
	sleep 1
	echo "1" > $vconsole
	sleep 2

	echo "3" > $vconsole
	sleep 1
	echo "6" > $vconsole
	sleep 2

	echo "A" > $vconsole
	sleep 1
	echo "2000k" > $vconsole
	sleep 1
	echo "2000k" > $vconsole
	sleep 2

	echo "B" > $vconsole
	sleep 1
	echo "2" > $vconsole
	sleep 2

	echo "C" > $vconsole
	sleep 1
	echo "1" > $vconsole
	sleep 2

	echo "I" > $vconsole
	sleep 1
	echo "1" > $vconsole
	sleep 2

	echo "W" > $vconsole
	sleep 3

	echo "S" > $vconsole
else
	echo "Usage: fvt_z3.sh {start | stop | init}"
	echo "  fvt_z3.sh start"
	echo "  fvt_z3.sh stop"
	echo "  fvt_z3.sh init"
fi

