#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <ftdi.h>

#include <unistd.h>

#define FTDI_VENDOR_ID					0x0403			// FTDI FT4232 vendor id
#define FTDI_PRODUCT_ID					0x6011			// FTDI FT4232 product id

#define FTDI_FAILURE					1
#define FTDI_SUCCESS					0

#define TOP_FAILURE					1
#define TOP_SUCCESS					0

struct		ftdi_context FTDI_PORTB;

// gcc -o ife_i2c_sel ife_i2c_sel.c $(pkg-config --cflags --libs libftdi)


/////////////////////////////////////////////////////////////////////////////////////////
// BitbangWritePortB
////////////////////////////////////////////////////////////////////////////////////////

void BitbangWritePortB(unsigned char BitbangDirection, unsigned char BitbangData)
	{
	int ReturnValue;

	unsigned char OutputBufferFTDI[8];			//Buffer to hold MPSSE commands and data to be sent to FT2232H

	ReturnValue = ftdi_set_bitmode(&FTDI_PORTB, BitbangDirection, BITMODE_BITBANG);
	if (ReturnValue < 0)
		{
		printf("Fail: Port B Set Bitmode error on ftdi\n");
		}

	OutputBufferFTDI[0] = BitbangData;

	ReturnValue = ftdi_write_data(&FTDI_PORTB, OutputBufferFTDI, 1);
	if (ReturnValue < 0)
		{
		printf("Fail: Port B Write Data error on ftdi\n");
		}
	}


int main(int argc, char* argv[])
	{
	
	int		FTDIStatus;	
	FTDIStatus = FTDISetupEzportReset();
		if (FTDIStatus == FTDI_FAILURE)
			{
			return TOP_FAILURE;
			}	

//	printf("\nDevice test Port B:\n");

	if(argc > 1) {
		if ( strcmp(argv[1],"0") == 0 ) {
			printf("Select x86 as I2C host\n");
			BitbangWritePortB(0x10, 0x00);
			//dir 0001 0000 ctrl_jtag_sel,eep_spi_s,fpga_EEP_sel,I2C_SEL| log_rst,fpga_rst,nc,nc   
			//dat 0000 0000 ctrl_jtag_sel,eep_spi_s,fpga_EEP_sel,i2c_sel| log_rst,fpga_rst,nc,nc
		}
		else if ( strcmp(argv[1],"1") == 0 ) {
			printf("Select k60 as I2C host\n");
			BitbangWritePortB(0x10, 0x10);
			//dir 0001 0000 ctrl_jtag_sel,eep_spi_s,fpga_EEP_sel,I2C_SEL| log_rst,fpga_rst,nc,nc   
			//dat 0001 0000 ctrl_jtag_sel,eep_spi_s,fpga_EEP_sel,i2c_sel| log_rst,fpga_rst,nc,nc
		}
		else {
			printf("Usage :\n");
			printf("  ife_i2c_sel 0 -> Select x86 as I2C host\n");
			printf("  ife_i2c_sel 1 -> Select k60 as I2C host\n");
		}
	}
	else {
		printf("Usage :\n");
		printf("  ife_i2c_sel 0 -> Select x86 as I2C host\n");
		printf("  ife_i2c_sel 1 -> Select k60 as I2C host\n");
	}

	return 0;
        }





/////////////////////////////////////////////////////////////////////////////////////////
// FTDISetupEzportReset
////////////////////////////////////////////////////////////////////////////////////////

int FTDISetupEzportReset(void)
	{
	int FTDIStatus;

	unsigned int FTDIClockDivisor = 0x0000;		//Value of clock divisor, Frequency = 60/((1+0x0000)*2) (MHz) = 30MHz

	unsigned int dwCount;

	
	if (ftdi_init(&FTDI_PORTB) < 0)
		{
		fprintf(stderr, "Port B init failed\n");
		return FTDI_FAILURE;
		}

	ftdi_set_interface(&FTDI_PORTB, INTERFACE_B);

	if ( (FTDIStatus = ftdi_usb_open(&FTDI_PORTB, FTDI_VENDOR_ID, FTDI_PRODUCT_ID)) < 0 )
		{
		fprintf(stderr, "Error: Port B unable to open FTDI device %d (%s)\n", FTDIStatus, ftdi_get_error_string(&FTDI_PORTB) );
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_usb_reset(&FTDI_PORTB);
	if (FTDIStatus < 0)
		{
		printf("Error: Port B reset error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTB, 0, 0);
	if (FTDIStatus < 0)
		{
		printf("Error: Port B set bitmode error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTB, 0x0, BITMODE_BITBANG);   //all pins are inputs
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B bitmode error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	return FTDI_SUCCESS;
	}




