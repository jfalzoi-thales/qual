#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <ftdi.h>
#include <stdint.h>
#include <unistd.h>

// This program is used to run the ftdi board.
//
// To compile this program, use the following command line:
//
// gcc -o ife_ezport_spi ife_ezport_spi.c $(pkg-config --cflags --libs libftdi)

#define FTDI_VENDOR_ID					0x0403			// FTDI FT4232 vendor id
#define FTDI_PRODUCT_ID					0x6011			// FTDI FT4232 product id

//#define ACK_FAILURE					1
//#define ACK_SUCCESS					0

//#define EZPORT_FAILURE					1
//#define EZPORT_SUCCESS					0

#define TOP_FAILURE					1
#define TOP_SUCCESS					0

#define FTDI_FAILURE					1
#define FTDI_SUCCESS					0

#define FILE_FAILURE					1
#define FILE_SUCCESS					0

#define INIT_FAILURE					1
#define INIT_SUCCESS					0

#define ERASE_FAILURE					1
#define ERASE_SUCCESS					0

#define PROGRAM_FAILURE					1
#define PROGRAM_SUCCESS					0

#define VERIFY_FAILURE					1
#define VERIFY_SUCCESS					0

#define EZPORT_CS_HIGH					1
#define EZPORT_CS_LOW					0

#define FILE_READ_YES					1
#define FILE_READ_NO					0

#define CODE_TYPE_BOTH					2
#define CODE_TYPE_APP					1
#define CODE_TYPE_BOOT					0

#define FLASH_IMAGE_BUFFER_CLEAR			1
#define FLASH_IMAGE_BUFFER_NO_CLEAR			0

#define FILE_TYPE_NONE					2
#define FILE_TYPE_INTEL_HEX				1
#define FILE_TYPE_S_RECORD				0

#define HEX_RECORD_LINE_SIZE				1000

#define INTEL_HEX_OK					1
#define INTEL_HEX_ERROR					0

#define COMMAND_SP_USLEEP_MICROSECONDS			100

#define COMMAND_WREN_USLEEP_MICROSECONDS		5000 

#define COMMAND_WRDI_USLEEP_MICROSECONDS		5000 

#define COMMAND_RDSR_USLEEP_MICROSECONDS		500 

#define COMMAND_BE_USLEEP_MICROSECONDS			100

#define COMMAND_RESET_USLEEP_MICROSECONDS		100

#define COMMAND_WRFCCOB_USLEEP_MICROSECONDS		100

#define COMMAND_FAST_RDFCCOB_USLEEP_MICROSECONDS	100

#define COMMAND_WRFLEXRAM_USLEEP_MICROSECONDS		100

#define COMMAND_RDFLEXRAM_USLEEP_MICROSECONDS		100

#define PROGRAM_ALGORITHM_USLEEP_MICROSECONDS		5000

#define WREN_COUNTER_RETRIES				32

#define KINETIS_FLASH_SIZE_IN_BYTES			(1024*512)		//K60 has 512kB of flash memory

#define KINETIS_PROGRAM_SIZE_IN_BYTES			512

#define KINETIS_VERIFY_SIZE_IN_BYTES			512

#define KINETIS_READ_BUFFER_SIZE_IN_BYTES		KINETIS_VERIFY_SIZE_IN_BYTES

#define DOT_PROGRESS_INTERVAL_PROGRAM			4096

#define DOT_PROGRESS_INTERVAL_VERIFY			(4 * DOT_PROGRESS_INTERVAL_PROGRAM)

//////////////////////////////////////////////////////////////////
// Define the global variables and const variables
//////////////////////////////////////////////////////////////////

unsigned char	*FileBuffer;					// Pointer to the file image in the system memory
unsigned long	FileLength;
unsigned long	FileIndex;

char		EzportSourceFilename[64];

FILE		*DetermineFile;
FILE		*IntelHexFile;
FILE		*FreescaleSRecordFile;

uint32_t	RecordIndex;
uint32_t	RecordDataLength;
uint32_t	RecordAddress;
uint32_t	RecordExtendedAddress;
uint8_t		RecordData;
uint16_t	RecordType;

uint32_t	IntelHexSegment;
uint32_t	IntelHexExtendedAddress;

unsigned char	glOutputBufferFTDI[4096];			//Buffer to hold MPSSE commands and data to be sent to FT2232H
unsigned char	glInputBufferFTDI[16384];			//Buffer to hold Data bytes to be read from FT2232H

unsigned long	KinetisFlashImageBufferDataIndex;
unsigned char	KinetisFlashImageBufferData[KINETIS_FLASH_SIZE_IN_BYTES];
unsigned char	KinetisFlashImageBufferMask[KINETIS_FLASH_SIZE_IN_BYTES];

unsigned char	KinetisFCCOBWriteBufferData[0x10];
unsigned char	KinetisFCCOBReadBufferData[0x10];

unsigned char	KinetisFlexRAMWriteBufferData[0x10];
unsigned char	KinetisFlexRAMReadBufferData[0x10];

unsigned char	KinetisEzportReadBufferData[KINETIS_READ_BUFFER_SIZE_IN_BYTES];

unsigned char	AppGoAddress[4];

unsigned char	BootParamConfig[256];

unsigned int	dwClockDivisor = 0x000e;			// clock divisor, Frequency = 60/((1+0x000e)*2) (MHz) = 2.00MHz

unsigned int	dwNumBytesToSend = 0;				//Index of output buffer
unsigned int	dwNumBytesSent = 0;
unsigned int	dwNumBytesRead = 0;
unsigned int	dwNumInputBuffer = 0;

struct		ftdi_context FTDI_PORTA;
struct		ftdi_context FTDI_PORTB;
//struct		ftdi_context FTDI_PORTC;
//struct		ftdi_context FTDI_PORTD;

enum		_SRecordDefinitions
			{
			SRECORD_RECORD_BUFF_SIZE	= 768,	// 768 should be plenty of space to read in an S-Record
			SRECORD_TYPE_OFFSET		= 1,	// Offsets and lengths of various fields in an S-Record record
			SRECORD_TYPE_LEN		= 1,
			SRECORD_COUNT_OFFSET		= 2,
			SRECORD_COUNT_LEN		= 2,
			SRECORD_ADDRESS_OFFSET		= 4,
			SRECORD_CHECKSUM_LEN		= 2,
			SRECORD_MAX_DATA_LEN		= 2*252,// Maximum ascii hex length of the S-Record data field
			SRECORD_MAX_ADDRESS_LEN		= 8,	// Maximum ascii hex length of the S-Record address field
			SRECORD_ASCII_HEX_BYTE_LEN	= 2,	// Ascii hex length of a single byte
			SRECORD_START_CODE_OFFSET	= 0,	// Start code offset and value
			SRECORD_START_CODE		= 'S',
			};

enum		SRecordErrors
			{
			SRECORD_OK			= 0, 	// Error code for success or no error.
			SRECORD_NO_ERROR		= 0, 	// Error code for success or no error.
			SRECORD_ERROR_FILE		= -1,	// Error code for reading from or writing to a file.
			SRECORD_ERROR_EOF		= -2,	// Error code for end-of-file when reading from a file.
			SRECORD_ERROR_INVALID_RECORD	= -3, 	// Error code for error if an invalid record was read.
			SRECORD_ERROR_INVALID_ARGUMENTS	= -4, 	// Error code for error from invalid arguments passed to function.
			SRECORD_ERROR_NEWLINE		= -5,	// Error code for newline with no record when reading from a file.
			};

enum		SRecordTypes
			{
			SRECORD_TYPE_S0			= 0,	// Header record. 16-bit address set to 0x0000 
			SRECORD_TYPE_S1,			// Data record with 16-bit address
			SRECORD_TYPE_S2,			// Data record with 24-bit address
			SRECORD_TYPE_S3,			// Data record with 32-bit address
			SRECORD_TYPE_S4,			// Reserved record type
			SRECORD_TYPE_S5,			// 16-bit address field with number of S1, S2, S3 records transmitted.
			SRECORD_TYPE_S6,			// 24-bit address field with number of S1, S2, S3 records transmitted.
			SRECORD_TYPE_S7,			// Termination record for S3 data records.
			SRECORD_TYPE_S8,			// Termination record for S2 data records.
			SRECORD_TYPE_S9,			// Termination record for S1 data records.
			};

typedef struct
			{
			uint32_t Address; 			// Address field (16, 24, or 32 bits depending on the record type).
			uint8_t Data[SRECORD_MAX_DATA_LEN / 2];	// 8-bit array data field (maximum size of 32 bytes).
			int16_t DataLength; 			// Number of bytes of data stored in this record.
			int16_t Type; 				// Freescale S-Record type of this record (S0-S9).
			uint8_t Checksum; 			// Checksum of this record.
			int16_t Error;
			} FreescaleSRecord;

unsigned char	FileReadFlag;

int16_t 	Read_FreescaleSRecord(FreescaleSRecord *, FILE *);
uint8_t 	Checksum_FreescaleSRecord(const FreescaleSRecord *);

unsigned char	DetermineFileType(void);

int		LoadHexFileIntoFlashImageBuffer(unsigned char, unsigned char);
int		LoadSrecFileIntoFlashImageBuffer(unsigned char, unsigned char);

int		FTDISetupEzportReset(void);

int		FTDISetupEzportProgram(void);

int		FTDIFreeEzport(void);

unsigned char	EzportBulkEraseAlgorithm(void);
unsigned char	EzportMultipleWordProgramAlgorithm(unsigned long, unsigned int);

int		EraseAppSectors(void);

void		ProgramBootParamConfig(void);

int		EnableEzport(void);

void		EzportWriteEnable_WREN(void);

void		EzportWriteDisable_WRDI(void);

unsigned char	EzportReadStatusRegister_RDSR(void);

unsigned char	EzportReadOneByte_READ(unsigned long);

void		EzportReadMultipleBytes_FAST_READ(unsigned long, unsigned int);

void		EzportSectionProgram_SP(unsigned long, unsigned int);

void		EzportSectorErase_SE(unsigned long);

void		EzportBulkErase_BE(void);

void		EzportReset_RESET(void);

void		EzportWriteFCCOBRegisters_WRFCCOB(void);

void		EzportReadFCCOBRegisters_FAST_RDFCCOB(unsigned int);

void		EzportWriteFlexRAM_WRFLEXRAM(unsigned long);

void		EzportReadFlexRAM_FAST_RDFLEXRAM(unsigned long, unsigned int);

void		ClearKinetisEzportReadBufferData(unsigned char);

void		BitbangWritePortA(unsigned char, unsigned char);

void		BitbangWritePortB(unsigned char, unsigned char);

int		InitEzport(void);
int		BulkEraseUsingEzport(void);
int		ProgramUsingEzport(unsigned char);
int		VerifyUsingEzport(unsigned char);

int main(int argc, char **argv)
	{
	FreescaleSRecord	FreeSRecord;

	unsigned char	FileType;

	unsigned char	ProgramFlag;

	unsigned int	LineCount;

	unsigned char	LineByteCount;
	unsigned int	LineAddress;
	unsigned int	LineByteIndex;
	unsigned char	LineByteData;

	unsigned char	StatusRegister;

	unsigned long	BufferIndex;

	unsigned char	ReadData;

	int		FTDIStatus;
	int		InitStatus;
	int		EraseStatus;
	int		ProgramStatus;
	int		VerifyStatus;
	int		ErrorStatus;

	unsigned long	DisplayIndexMSB;
	unsigned long	DisplayIndexLSB;

	unsigned long	DisplayAddress;

	unsigned char	CodeType;

	if (argc < 2)
		{
		printf ("\n");
		printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");

		return TOP_FAILURE;
		}

	switch (argv[1][0])
		{
		case 'h' :
		case 'H' :
		case '?' :
			printf("\n");
			printf("IFE_EZPORT_SPI HELP:\n");
			printf("ife_ezport_spi [ h|H|? ]                         ife_ezport_spi help\n");
			printf ("\n");
			printf("ife_ezport_spi [ a|A ]                           IFE ezport test Port A\n");
			printf("ife_ezport_spi [ b|B ]                           IFE ezport test FTDI_CTRL_RST_N\n");
			printf("ife_ezport_spi [ t|T ]                           IFE ezport test algorithms\n");
			printf ("\n");
			printf("ife_ezport_spi [ e|E ]                           IFE ezport erase K60 flash\n");
			printf("ife_ezport_spi [ p|P ] [ b|B ] bootfile          IFE ezport program/verify K60 Boot flash\n");
			printf("ife_ezport_spi [ p|P ] [ a|A ] appfile           IFE ezport program/verify K60 App flash\n");
			printf("ife_ezport_spi [ f|F ] bootfile appfile          IFE ezport program/verify K60 entire flash\n");
			printf("ife_ezport_spi [ d|D ] dispaddr                  IFE ezport display K60 flash\n");
			printf ("\n");
			return TOP_SUCCESS;
			break;

		case 'a':
		case 'A':
			printf("\nDevice test Port A:\n");

			FileReadFlag = FILE_READ_NO;

			FTDIStatus = FTDISetupEzportReset();
			if (FTDIStatus == FTDI_FAILURE)
				{
				return TOP_FAILURE;
				break;
				}

			for (;;)
				{
				BitbangWritePortA(0xfb, 0x88);	//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
								//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
				usleep(10000);

				BitbangWritePortA(0xfb, 0x08);	//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
								//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
				usleep(10000);

				BitbangWritePortA(0xfb, 0x88);	//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
								//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
				usleep(10000);

				BitbangWritePortA(0x00, 0x88);	//dir 0000 0000 ezpcs,fpgaeecs,brsweecs,nc | fpgacs,do,di,sk
								//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
				usleep(10000);
				}

			printf ("\n");

			return TOP_SUCCESS;
			break;

		case 'b':
		case 'B':
			printf("\nDevice test Port B:\n");

			FileReadFlag = FILE_READ_NO;

			FTDIStatus = FTDISetupEzportReset();
			if (FTDIStatus == FTDI_FAILURE)
				{
				return TOP_FAILURE;
				}

			BitbangWritePortB(0x02, 0x02);	//dir 1111 1111 VMODPWR,NC,CPU_RST,NC | NC,NC,VMODRX,VMODTX
							//dat 1010 0011 VMODPWR,nc,CPU_RST,nc | nc,nc,VMODRX,VMODTX
			usleep(50000);

			BitbangWritePortB(0x02, 0x00);	//dir 1111 1111 VMODPWR,NC,CPU_RST,NC | NC,NC,VMODRX,VMODTX
							//dat 1000 0011 VMODPWR,nc,cpu_rst,nc | nc,nc,VMODRX,VMODTX
			usleep(50000);

			BitbangWritePortB(0x02, 0x02);	//dir 1111 1111 VMODPWR,NC,CPU_RST,NC | NC,NC,VMODRX,VMODTX
							//dat 1010 0011 VMODPWR,nc,CPU_RST,nc | nc,nc,VMODRX,VMODTX
			usleep(50000);

			BitbangWritePortB(0x00, 0x02);	//dir 1111 1111 vmodpwr,nc,cpu_rst,nc | nc,nc,vmodrx,vmodtx
							//dat 1010 0011 VMODPWR,nc,CPU_RST,nc | nc,nc,VMODRX,VMODTX
			usleep(50000);

			printf ("\n");

			return TOP_SUCCESS;
			break;

		case 't':
		case 'T':
			printf("\nDevice test algorithms:\n");

			FileReadFlag = FILE_READ_NO;

			InitStatus = InitEzport();
			if (InitStatus == INIT_FAILURE)
				{
				return TOP_FAILURE;
				break;
				}

			EzportWriteEnable_WREN();

			while ((EzportReadStatusRegister_RDSR() & 0x02) != 0x02)
				{
				}

			StatusRegister = EzportReadStatusRegister_RDSR();

			printf ("RDSR Status Register before BE: %02X\n", StatusRegister);

			EzportBulkErase_BE();

			while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
				{
				}

			for (BufferIndex = 0x000; BufferIndex < 16; BufferIndex++)
				{
				KinetisFlashImageBufferData[BufferIndex] = 15 - BufferIndex;
				}

			EzportWriteEnable_WREN();

			while ((EzportReadStatusRegister_RDSR() & 0x02) != 0x02)
				{
				}

			EzportSectionProgram_SP(0x00000, 16);

			while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
				{
				}

			EzportReadMultipleBytes_FAST_READ(0x00000, 16);

			for (BufferIndex = 0x00000; BufferIndex < 16; BufferIndex++)
				{
				ReadData = KinetisEzportReadBufferData[BufferIndex];

				printf("Info: Kinetis Address: %lX Data: %02X\n", BufferIndex, ReadData);
				}

			printf ("\n");

			return TOP_SUCCESS;
			break;

		case 'e':
		case 'E':
			FileReadFlag = FILE_READ_NO;
			break;

		case 'p':
		case 'P':
			FileReadFlag = FILE_READ_NO;
			if (argc < 4)
				{
				printf ("\n");
				printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");
				return TOP_FAILURE;
				}

			switch(argv[2][0])
				{
				case 'b':
				case 'B':
					CodeType = CODE_TYPE_BOOT;
					break;

				case 'a':
				case 'A':
					CodeType = CODE_TYPE_APP;
					break;
				}

			FileReadFlag = FILE_READ_YES;
			printf ("\n");
			printf("  #####################################################################\n");
			printf("  IIIII  FFFFF  EEEEE          EEEEE  ZZZZZ  PPPP    OOO   RRRR   TTTTT\n");
			printf("    I    F      E              E          Z  P   P  O   O  R   R    T  \n");
			printf("    I    F      E              E         Z   P   P  O   O  RRRR     T  \n");
			printf("    I    FFFFF  EEEEE          EEEEE    Z    PPPP   O   O  RR       T  \n");
			printf("    I    F      E              E       Z     P      O   O  R R      T  \n");
			printf("    I    F      E              E      Z      P      O   O  R  R     T  \n");
			printf("  IIIII  F      EEEEE          EEEEE  ZZZZZ  P       OOO   R   R    T  \n");
			printf("  #####################################################################\n");
			break;

		case 'f':
		case 'F':
			FileReadFlag = FILE_READ_NO;
			if (argc < 4)
				{
				printf ("\n");
				printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");
				return TOP_FAILURE;
				}

			CodeType = CODE_TYPE_BOTH;

			FileReadFlag = FILE_READ_YES;
			printf ("\n");
			printf("  #####################################################################\n");
			printf("  IIIII  FFFFF  EEEEE          EEEEE  ZZZZZ  PPPP    OOO   RRRR   TTTTT\n");
			printf("    I    F      E              E          Z  P   P  O   O  R   R    T  \n");
			printf("    I    F      E              E         Z   P   P  O   O  RRRR     T  \n");
			printf("    I    FFFFF  EEEEE          EEEEE    Z    PPPP   O   O  RR       T  \n");
			printf("    I    F      E              E       Z     P      O   O  R R      T  \n");
			printf("    I    F      E              E      Z      P      O   O  R  R     T  \n");
			printf("  IIIII  F      EEEEE          EEEEE  ZZZZZ  P       OOO   R   R    T  \n");
			printf("  #####################################################################\n");
			break;

		case 'd':
		case 'D':
			FileReadFlag = FILE_READ_NO;
			if (argc < 3)
				{
				printf ("\n");
				printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");
				return TOP_FAILURE;
				break;
				}

			DisplayAddress = (unsigned long) strtoul(argv[2], NULL, 0);
			break;

		default:
			FileReadFlag = FILE_READ_NO;
			printf ("\n");
			printf("Error: Refer to help screen for program details!\n\n");

			return TOP_FAILURE;
			break;
		}

	if (FileReadFlag == FILE_READ_YES)
		{
		if (CodeType == CODE_TYPE_BOOT)
			{
			memcpy (EzportSourceFilename, argv[3], strlen(argv[3]) + 1);

			FileType = DetermineFileType();

			switch (FileType)
				{
				case FILE_TYPE_S_RECORD:
					printf ("\n");
					printf("Info: Freescale S-Record file detected\n");
					ErrorStatus = LoadSrecFileIntoFlashImageBuffer(FLASH_IMAGE_BUFFER_CLEAR, CodeType);
					break;
				case FILE_TYPE_INTEL_HEX:
					printf ("\n");
					printf("Info: Intel Hex file detected\n");
					ErrorStatus = LoadHexFileIntoFlashImageBuffer(FLASH_IMAGE_BUFFER_CLEAR, CodeType);
					break;
				default:
					printf ("\n");
					printf("Error: Refer to help screen for program details!\n\n");
					return TOP_FAILURE;
					break;
				}
			}
		else if (CodeType == CODE_TYPE_APP)
			{
			memcpy (EzportSourceFilename, argv[3], strlen(argv[3]) + 1);
			ErrorStatus = LoadSrecFileIntoFlashImageBuffer(FLASH_IMAGE_BUFFER_CLEAR, CodeType);
			}
		else
			{
			memcpy (EzportSourceFilename, argv[2], strlen(argv[2]) + 1);
			ErrorStatus = LoadSrecFileIntoFlashImageBuffer(FLASH_IMAGE_BUFFER_CLEAR, CODE_TYPE_BOOT);

			memcpy (EzportSourceFilename, argv[3], strlen(argv[3]) + 1);
			ErrorStatus = LoadSrecFileIntoFlashImageBuffer(FLASH_IMAGE_BUFFER_NO_CLEAR, CODE_TYPE_APP);
			}
		}





	switch (argv[1][0])
		{
		case 'e':
		case 'E':
			printf("\nEzport Flash erase:\n");
			InitStatus = InitEzport();
			if (InitStatus == INIT_FAILURE)
				{
				return TOP_FAILURE;
				break;
				}

			BulkEraseUsingEzport();
			if (EraseStatus == ERASE_FAILURE)
				{
				return TOP_FAILURE;
				break;
				}

			printf ("\n\n");
			break;

		case 'p':
		case 'P':
			switch(argv[2][0])
				{
				case 'b':
				case 'B':
					printf("Info: Ezport Flash program with Boot code\n");

					CodeType = CODE_TYPE_BOOT;

					InitStatus = InitEzport();
					if (InitStatus == INIT_FAILURE)
						{
						return TOP_FAILURE;
						break;
						}

					EraseStatus = BulkEraseUsingEzport();
					if (EraseStatus == ERASE_FAILURE)
						{
						return TOP_FAILURE;
						break;
						}

					while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
						{
						}

					ProgramStatus = ProgramUsingEzport(CodeType);
					if (ProgramStatus == PROGRAM_FAILURE)
						{
						return TOP_FAILURE;
						break;
						}

					VerifyStatus = VerifyUsingEzport(CodeType);
					if (VerifyStatus == VERIFY_FAILURE)
						{
						return TOP_FAILURE;
						break;
						}
					break;

				case 'a':
				case 'A':
					printf("Info: Ezport Flash program with App code\n");

					CodeType = CODE_TYPE_APP;

					InitStatus = InitEzport();
					if (InitStatus == INIT_FAILURE)
						{
						return TOP_FAILURE;
						break;
						}

					EzportReadMultipleBytes_FAST_READ(0x7f800, 256);

					for (BufferIndex = 0; BufferIndex < 256; BufferIndex++)
						{
						BootParamConfig[BufferIndex] = KinetisEzportReadBufferData[BufferIndex];
						}

					EzportSectorErase_SE(0x7f800);

					while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
						{
						}

					BootParamConfig[52] = AppGoAddress[3];
					BootParamConfig[53] = AppGoAddress[2];
					BootParamConfig[54] = AppGoAddress[1];
					BootParamConfig[55] = AppGoAddress[0];

					EzportWriteEnable_WREN();

					StatusRegister = EzportReadStatusRegister_RDSR();

					while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
						{
						}

					ProgramBootParamConfig();

					while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
						{
						}

					EraseStatus = EraseAppSectors();
					if (EraseStatus == ERASE_FAILURE)
						{
						return TOP_FAILURE;
						break;
						}

					ProgramStatus = ProgramUsingEzport(CodeType);
					if (ProgramStatus == PROGRAM_FAILURE)
						{
						return TOP_FAILURE;
						break;
						}

					VerifyStatus = VerifyUsingEzport(CodeType);
					if (VerifyStatus == VERIFY_FAILURE)
						{
						return TOP_FAILURE;
						break;
						}
					break;
				}
			break;

		case 'f':
		case 'F':
			printf("Info: Ezport Flash program with Boot and App code\n");

			KinetisFlashImageBufferData[0x7f800 + 52] = AppGoAddress[3];
			KinetisFlashImageBufferData[0x7f800 + 53] = AppGoAddress[2];
			KinetisFlashImageBufferData[0x7f800 + 54] = AppGoAddress[1];
			KinetisFlashImageBufferData[0x7f800 + 55] = AppGoAddress[0];

			CodeType = CODE_TYPE_BOTH;

			InitStatus = InitEzport();
			if (InitStatus == INIT_FAILURE)
				{
				return TOP_FAILURE;
				break;
				}

			EraseStatus = BulkEraseUsingEzport();
			if (EraseStatus == ERASE_FAILURE)
				{
				return TOP_FAILURE;
				break;
				}

			while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
				{
				}

			ProgramStatus = ProgramUsingEzport(CodeType);
			if (ProgramStatus == EXIT_FAILURE)
				{
				return TOP_FAILURE;
				break;
				}

			VerifyStatus = VerifyUsingEzport(CodeType);
			if (VerifyStatus == VERIFY_FAILURE)
				{
				return TOP_FAILURE;
				break;
				}
			break;

		case 'd' :
		case 'D' :
			printf("\nEzport Flash display:\n");

			InitStatus = InitEzport();
			if (InitStatus == INIT_FAILURE)
				{
				return TOP_FAILURE;
				break;
				}

			printf ("\n");

			for (DisplayIndexMSB = 0; DisplayIndexMSB < 32; DisplayIndexMSB++)
				{
				printf (" 0x%05lX : ", DisplayAddress + (DisplayIndexMSB * 16));
				printf ("0x%04lXF: ", DisplayIndexMSB);

				EzportReadMultipleBytes_FAST_READ(DisplayAddress + (DisplayIndexMSB * 16), 16);

				for (DisplayIndexLSB = 0; DisplayIndexLSB < 16; DisplayIndexLSB++)
					{
					ReadData = KinetisEzportReadBufferData[DisplayIndexLSB];

					printf ("0x%02X ", ReadData);
					}

				printf ("\n");
				}

			printf("\n");
			break;

		default:
			printf("\nError: Refer to help screen for program details!\n");
			printf ("\n\n");
			break;
		}

	return EXIT_SUCCESS;
	}

/****************************************************************************/
/*                                                                          */
/*  Function:         InitEzport                                            */
/*                                                                          */
/****************************************************************************/

int InitEzport()
	{
	unsigned char	InitEzportStatus;

	EnableEzport();

	EzportWriteEnable_WREN();

	InitEzportStatus = EzportReadStatusRegister_RDSR();

	if ((InitEzportStatus & 0x02) != 0x02)
		{
		printf("Fail: Ezport Initialization\n");
		return INIT_FAILURE;
		}
	else
		{
		printf("Pass: Ezport Initialization\n");
		}

	return INIT_SUCCESS;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EnableEzport
////////////////////////////////////////////////////////////////////////////////////////

int EnableEzport()
	{
	int FTDIStatus;

	FTDIStatus = FTDISetupEzportReset();

	if (FTDIStatus == EXIT_FAILURE)
		{
		return FTDI_FAILURE;
		}

	BitbangWritePortB(0x80, 0x80);			//dir 1111 1111 VMODPWR,NC,CPU_RST,NC | NC,NC,VMODRX,VMODTX
							//dat 1010 0011 VMODPWR,nc,CPU_RST,nc | nc,nc,VMODRX,VMODTX
	usleep(50000);

	BitbangWritePortA(0xfb, 0x88);			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
							//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	usleep(50000);

	BitbangWritePortA(0xfb, 0x08);			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
							//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	usleep(50000);

	BitbangWritePortB(0x82, 0x82);			//dir 1111 1111 VMODPWR,NC,CPU_RST,NC | NC,NC,VMODRX,VMODTX
							//dat 1010 0011 VMODPWR,nc,CPU_RST,nc | nc,nc,VMODRX,VMODTX
	usleep(50000);

	BitbangWritePortB(0x82, 0x80);			//dir 1111 1111 VMODPWR,NC,CPU_RST,NC | NC,NC,VMODRX,VMODTX
							//dat 1000 0011 VMODPWR,nc,cpu_rst,nc | nc,nc,VMODRX,VMODTX
	usleep(50000);

	BitbangWritePortB(0x82, 0x82);			//dir 1111 1111 VMODPWR,NC,CPU_RST,NC | NC,NC,VMODRX,VMODTX
							//dat 1010 0011 VMODPWR,nc,CPU_RST,nc | nc,nc,VMODRX,VMODTX
	usleep(1000000);

	BitbangWritePortA(0xfb, 0x88);			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
							//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	usleep(50000);

	FTDIStatus = FTDISetupEzportProgram();

	if (FTDIStatus == EXIT_FAILURE)
		{
		return FTDI_FAILURE;
		}

	return FTDI_SUCCESS;
	}

/****************************************************************************/
/*                                                                          */
/*  Function:         BulkEraseUsingEzport                                  */
/*                                                                          */
/****************************************************************************/

int BulkEraseUsingEzport()
	{
	unsigned char	BulkEraseEzportStatus;

	unsigned long	BulkEraseError;

	unsigned long	BulkEraseBufferIndex;

	unsigned long	BulkEraseLineByteIndex;

	BulkEraseEzportStatus = EzportBulkEraseAlgorithm();

	if (BulkEraseEzportStatus == ERASE_FAILURE)
		{
		printf("Fail: Ezport Bulk Erase Command (Code 1)\n");
		return ERASE_FAILURE;
		}

	BulkEraseEzportStatus = EzportReadStatusRegister_RDSR();

	if ((BulkEraseEzportStatus & 0x40) == 0x40)
		{
		printf("Fail: Ezport Bulk Erase Command (Code 2)\n");
		return ERASE_FAILURE;
		}

	BulkEraseError = 0;

	for (	BulkEraseBufferIndex = 0;
		BulkEraseBufferIndex < KINETIS_FLASH_SIZE_IN_BYTES;
		BulkEraseBufferIndex = BulkEraseBufferIndex + KINETIS_VERIFY_SIZE_IN_BYTES)
		{
		ClearKinetisEzportReadBufferData(0x00);

		EzportReadMultipleBytes_FAST_READ(BulkEraseBufferIndex, KINETIS_VERIFY_SIZE_IN_BYTES);

		for (	BulkEraseLineByteIndex = 0;
			BulkEraseLineByteIndex < KINETIS_VERIFY_SIZE_IN_BYTES;
			BulkEraseLineByteIndex++)
			{
			if ((BulkEraseBufferIndex + BulkEraseLineByteIndex) != 0x040c)		//this address is always a problem.
				{
				if (KinetisEzportReadBufferData[BulkEraseLineByteIndex] != 0xff)
					{
					BulkEraseError = 1;
					printf("Fail: Ezport Bulk Erase Address: %16lX Read: %02X\n",
							BulkEraseBufferIndex + BulkEraseLineByteIndex,
							KinetisEzportReadBufferData[BulkEraseLineByteIndex]);
					}
				}
			}
		}

	if (BulkEraseError != 0)
		{
		printf("Fail: Ezport Bulk Erase Error\n");
		return ERASE_FAILURE;
		}

	if (BulkEraseError == 0)
		{
		printf("Pass: Ezport Bulk Erase Success\n");
		EzportReset_RESET();
		}

	return ERASE_SUCCESS;
	}

/****************************************************************************/
/*                                                                          */
/*  Function:         ProgramUsingEzport                                    */
/*                                                                          */
/****************************************************************************/

int ProgramUsingEzport(unsigned char CodeTypeToProgram)
	{
	unsigned char	ProgramEzportStatus;

	unsigned long	ProgramLineCount;

	unsigned long	ProgramImageIndex;

	unsigned long	ProgramError;

	unsigned long	ProgramWriteBufferIndex;

	unsigned char	ProgramFlag;

	unsigned long	ProgramLineByteIndex;

	ProgramError = 0;

	if (CodeTypeToProgram == CODE_TYPE_BOOT)
		{
		printf("Info: Ezport Programming Boot Flash .");
		}
	else if (CodeTypeToProgram == CODE_TYPE_APP)
		{
		printf("Info: Ezport Programming App Flash .");
		}
	else if (CodeTypeToProgram == CODE_TYPE_BOTH)
		{
		printf("Info: Ezport Programming Boot and App Flash .");
		}
	else
		{
		printf("Info: Ezport Programming Flash .");
		}

	fflush(stdout);

	for (	ProgramWriteBufferIndex = 0;
		ProgramWriteBufferIndex < KINETIS_FLASH_SIZE_IN_BYTES;
		ProgramWriteBufferIndex = ProgramWriteBufferIndex + KINETIS_PROGRAM_SIZE_IN_BYTES)
		{
		ProgramFlag = 0;

		for (	ProgramLineByteIndex = 0;
			ProgramLineByteIndex < KINETIS_PROGRAM_SIZE_IN_BYTES;
			ProgramLineByteIndex++)
			{
			if (KinetisFlashImageBufferData[ProgramWriteBufferIndex + ProgramLineByteIndex] != 0xff)
				{
				if (KinetisFlashImageBufferMask[ProgramWriteBufferIndex + ProgramLineByteIndex])
	 				{
					ProgramFlag = 1;
					break;
					}
				}
			}

		if (ProgramFlag)
			{
			if (ProgramWriteBufferIndex % (DOT_PROGRESS_INTERVAL_PROGRAM) == 0)
				{
				printf(".");
				fflush(stdout);
				}

			ProgramEzportStatus = EzportMultipleWordProgramAlgorithm(ProgramWriteBufferIndex,
										 KINETIS_PROGRAM_SIZE_IN_BYTES);

			if (ProgramEzportStatus == PROGRAM_FAILURE)
				{
				printf("\n");
				printf("Fail: Ezport Multiple Bytes Program Algorithm\n");
				printf("\n");
				ProgramError += 1;

				return PROGRAM_FAILURE;
				}
			}
		}

	printf("\n");

	if (ProgramError)
		{
		if (CodeTypeToProgram == CODE_TYPE_BOOT)
			{
			printf("Fail: Ezport Boot Flash Programming Error\n");
			}
		else if (CodeTypeToProgram == CODE_TYPE_APP)
			{
			printf("Fail: Ezport App Flash Programming Error\n");
			}
		else if (CodeTypeToProgram == CODE_TYPE_BOTH)
			{
			printf("Fail: Ezport Boot and App Flash Programming Error\n");
			}
		else
			{
			printf("Fail: Ezport Flash Programming Error\n");
			}
		return PROGRAM_FAILURE;
		}
	else
		{
		if (CodeTypeToProgram == CODE_TYPE_BOOT)
			{
			printf("Pass: Ezport Boot Flash Programming Complete\n");
			}
		else if (CodeTypeToProgram == CODE_TYPE_APP)
			{
			printf("Pass: Ezport App Flash Programming Complete\n");
			}
		else if (CodeTypeToProgram == CODE_TYPE_BOTH)
			{
			printf("Pass: Ezport Boot and App Flash Programming Complete\n");
			}
		else
			{
			printf("Pass: Ezport Flash Programming Complete\n");
			}
		return PROGRAM_SUCCESS;
		}
	}

/****************************************************************************/
/*                                                                          */
/*  Function:         VerifyUsingEzport                                     */
/*                                                                          */
/****************************************************************************/

int VerifyUsingEzport(unsigned char CodeTypeToVerify)
	{
	unsigned char	VerifyEzportStatus;

	unsigned long	VerifyError;

	unsigned long	VerifyBufferIndex;

	unsigned long	VerifyLineByteIndex;

	VerifyError = 0;

	if (CodeTypeToVerify == CODE_TYPE_BOOT)
		{
		printf("Info: Ezport Verifying Boot Flash .");
		}
	else if (CodeTypeToVerify == CODE_TYPE_APP)
		{
		printf("Info: Ezport Verifying App Flash .");
		}
	else if (CodeTypeToVerify == CODE_TYPE_BOTH)
		{
		printf("Info: Ezport Verifying Boot and App Flash .");
		}
	else
		{
		printf("Info: Ezport Verifying Flash .");
		}

	for (	VerifyBufferIndex = 0;
		VerifyBufferIndex < KINETIS_FLASH_SIZE_IN_BYTES;
		VerifyBufferIndex = VerifyBufferIndex + KINETIS_VERIFY_SIZE_IN_BYTES)
		{
		if (VerifyBufferIndex % (DOT_PROGRESS_INTERVAL_VERIFY) == 0)
			{
			printf(".");
			fflush(stdout);
			}

		ClearKinetisEzportReadBufferData(0xff);

		EzportReadMultipleBytes_FAST_READ(VerifyBufferIndex, KINETIS_VERIFY_SIZE_IN_BYTES);

		for (	VerifyLineByteIndex = 0;
			VerifyLineByteIndex < KINETIS_VERIFY_SIZE_IN_BYTES;
			VerifyLineByteIndex++)
			{
//			if ((VerifyBufferIndex + VerifyLineByteIndex) != 0x040c)		//this address is always a problem.
//				{
				if (KinetisFlashImageBufferMask[VerifyBufferIndex + VerifyLineByteIndex])
					{
					if (	KinetisFlashImageBufferData[VerifyBufferIndex + VerifyLineByteIndex] !=
						KinetisEzportReadBufferData[VerifyLineByteIndex])
						{
						VerifyError = 1;
						printf("Fail: Write Buffer Address: %16lX Write: %02X Read: %02X\n",
								VerifyBufferIndex + VerifyLineByteIndex,
								KinetisFlashImageBufferData[VerifyBufferIndex + VerifyLineByteIndex],
								KinetisEzportReadBufferData[VerifyLineByteIndex]);
						break;
						}
					}

//				}

			}
		}

	printf("\n");

	if (VerifyError != 0)
		{
		if (CodeTypeToVerify == CODE_TYPE_BOOT)
			{
			printf("Fail: Ezport Boot Flash Verify Error\n");
			}
		else if (CodeTypeToVerify == CODE_TYPE_APP)
			{
			printf("Fail: Ezport App Flash Verify Error\n");
			}
		else if (CodeTypeToVerify == CODE_TYPE_BOTH)
			{
			printf("Fail: Ezport Boot and App Flash Verify Error\n");
			}
		else
			{
			printf("Fail: Ezport Flash Verify Error\n");
			}
		return VERIFY_FAILURE;
		}

	if (VerifyError == 0)
		{
		if (CodeTypeToVerify == CODE_TYPE_BOOT)
			{
			printf("Pass: Ezport Boot Flash Verify Success\n");
			}
		else if (CodeTypeToVerify == CODE_TYPE_APP)
			{
			printf("Pass: Ezport App Flash Verify Success\n");
			}
		else if (CodeTypeToVerify == CODE_TYPE_BOTH)
			{
			printf("Pass: Ezport Boot and App Flash Verify Success\n");
			}
		else
			{
			printf("Pass: Ezport Flash Verify Success\n");
			}

		EzportReset_RESET();
		}

	return VERIFY_SUCCESS;
	}


//////////////////// HIGHER LEVEL FUNCTIONS///////////////////////////////////

/****************************************************************************/
/*                                                                          */
/*  Function:         EzportBulkEraseAlgorithm                              */
/*                                                                          */
/****************************************************************************/

unsigned char EzportBulkEraseAlgorithm()
	{
	unsigned char EzportStatus;

	EzportWriteEnable_WREN();

	EzportStatus = EzportReadStatusRegister_RDSR();

	if ((EzportStatus & 0x02) != 0x02)
		{
		printf("\n");
		printf("Fail: Ezport Bulk Erase Write Enable Command WREN before bulk erase\n");
		return ERASE_FAILURE;
		}

	EzportBulkErase_BE();

	EzportStatus = EzportReadStatusRegister_RDSR();

	if ((EzportStatus & 0x40) == 0x40)
		{
		printf("\n");
		printf("Fail: Ezport Bulk Erase Write Error Flag set after bulk erase (code 1)\n");
		return ERASE_FAILURE;
		}

	while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
		{
		}

	EzportStatus = EzportReadStatusRegister_RDSR();

	if ((EzportStatus & 0x40) == 0x40)
		{
		printf("\n");
		printf("Fail: Ezport Bulk Erase Write Error Flag set after bulk erase (code 2)\n");
		return ERASE_FAILURE;
		}

	return ERASE_SUCCESS;
	}

/****************************************************************************/
/*                                                                          */
/*  Function:         EzportMultipleWordProgramAlgorithm                    */
/*                                                                          */
/****************************************************************************/

unsigned char EzportMultipleWordProgramAlgorithm(unsigned long EzportStartAddress, unsigned int EzportNumberOfBytes)
	{
	unsigned char EzportStatus;

	unsigned char WRENCounter;

//	EzportWriteEnable_WREN();

	EzportStatus = EzportReadStatusRegister_RDSR();

	if ((EzportStatus & 0xff) == 0xff)
		{
		printf("\n");
		printf("Fail: Ezport Multiple Word Error reading Status Register\n");
		return PROGRAM_FAILURE;
		}

	if ((EzportStatus & 0x80) == 0x80)
		{
		printf("\n");
		printf("Fail: Ezport Multiple Word Flash is secure and can not be programmed\n");
		return PROGRAM_FAILURE;
		}

	WRENCounter = 0;

	do
		{
		EzportWriteEnable_WREN();

		EzportStatus = EzportReadStatusRegister_RDSR();

		if ( ((EzportStatus & 0x02) != 0x02) && (WRENCounter >= WREN_COUNTER_RETRIES) )
			{
			printf("\n");
			printf("Fail: Ezport Multiple Word Write Enable Command WREN before byte programming\n");
			return PROGRAM_FAILURE;
			}

		WRENCounter++;
		} while ((EzportStatus & 0x02) != 0x02);

	while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
		{
		}

	EzportSectionProgram_SP(EzportStartAddress, EzportNumberOfBytes);

	usleep(PROGRAM_ALGORITHM_USLEEP_MICROSECONDS);

	EzportStatus = EzportReadStatusRegister_RDSR();

	if ((EzportStatus & 0x40) == 0x40)
		{
		printf("\n");
		printf("Fail: Ezport Multiple Word Write Error Flag set after byte programming (code 1) address: %016lu\n", EzportStartAddress);
		return PROGRAM_FAILURE;
		}

	while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
		{
		}

	EzportStatus = EzportReadStatusRegister_RDSR();

	if ((EzportStatus & 0x40) == 0x40)
		{
		printf("\n");
		printf("Fail: Ezport Multiple Word Write Error Flag set after byte programming (code 2) address: %016lu\n", EzportStartAddress);
		return PROGRAM_FAILURE;
		}

	return PROGRAM_SUCCESS;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EraseAppSectors
////////////////////////////////////////////////////////////////////////////////////////

int EraseAppSectors()
	{
	unsigned char EzportStatus;

	unsigned long EraseSectorAddress;

	EzportStatus = EzportReadStatusRegister_RDSR();

	if ((EzportStatus & 0x40) == 0x40)
		{
		printf("\n");
		printf("Fail: Ezport Erase Application Sectors before sector erase\n");
		return ERASE_FAILURE;
		}

	for (EraseSectorAddress = 0x0c000; EraseSectorAddress < 0x50000; EraseSectorAddress = EraseSectorAddress + 2048)
		{
		EzportWriteEnable_WREN();

		while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
			{
			}

		EzportSectorErase_SE(EraseSectorAddress);

		while ((EzportReadStatusRegister_RDSR() & 0x01) == 0x01)
			{
			}

		EzportStatus = EzportReadStatusRegister_RDSR();

		if ((EzportStatus & 0x40) == 0x40)
			{
			printf("\n");
			printf("Fail: Ezport Erase Application Sectors during sector erase\n");
			return ERASE_FAILURE;
			}
		}

	return ERASE_SUCCESS;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// ProgramBootParamConfig
////////////////////////////////////////////////////////////////////////////////////////

void ProgramBootParamConfig()
	{
	unsigned int CountBytesToSend;

	unsigned int BufferIndex;

	unsigned int EzportNumberOfBytes;

	unsigned long FlashStartAddress;

	unsigned char FlashStartAddressHigh;
	unsigned char FlashStartAddressMid;
	unsigned char FlashStartAddressLow;

	unsigned char EzportNumberOfBytesHigh;
	unsigned char EzportNumberOfBytesLow;

	FlashStartAddress = 0x0007f800;

	EzportNumberOfBytes = 256;

	FlashStartAddressHigh = (unsigned char) (0xff & (FlashStartAddress >> 16));

	FlashStartAddressMid = (unsigned char) (0xff & (FlashStartAddress >> 8));

	FlashStartAddressLow = (unsigned char) (0xff & (FlashStartAddress));

	EzportNumberOfBytesHigh = (unsigned char) (((EzportNumberOfBytes - 1) >> 8) & 0xff);
	EzportNumberOfBytesLow = (unsigned char) ((EzportNumberOfBytes - 1) & 0xff);

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x02;			//Send a byte of 0x02 to perform SP command

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x02;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressHigh;	//Send high byte of flash address
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressMid;	//Send mid byte of flash address
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressLow;	//Send low byte of flash address

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;					//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesLow;		//Set length to number of bytes
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesHigh;		//Set length to number of bytes

	for (BufferIndex = 0; BufferIndex < EzportNumberOfBytes; BufferIndex++)
		{
		glOutputBufferFTDI[CountBytesToSend++] = BootParamConfig[BufferIndex];	//Send byte of data
		}

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	usleep(COMMAND_SP_USLEEP_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportWriteEnable_WREN
////////////////////////////////////////////////////////////////////////////////////////

void EzportWriteEnable_WREN(void)
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x06;			//Send a byte of 0x06 to perform WREN command

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	usleep(COMMAND_WREN_USLEEP_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportWriteDisable_WRDI
////////////////////////////////////////////////////////////////////////////////////////

void EzportWriteDisable_WRDI(void)
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x04;			//Send a byte of 0x04 to perform WRDI command

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	usleep(COMMAND_WRDI_USLEEP_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportReadStatusRegister_RDSR
////////////////////////////////////////////////////////////////////////////////////////

unsigned char EzportReadStatusRegister_RDSR()
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	unsigned char StatusRegister;

	ftdi_usb_purge_rx_buffer(&FTDI_PORTA);

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x05;			//Send a byte of 0x05 to perform RDSR command

	glOutputBufferFTDI[CountBytesToSend++] = 0x31;			//Command to send/receive byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Send one empty byte

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	ftdi_read_data(&FTDI_PORTA, glInputBufferFTDI, 1);

	StatusRegister = glInputBufferFTDI[0] & 0xff;

	usleep(COMMAND_RDSR_USLEEP_MICROSECONDS);

	return StatusRegister;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportReadOneByte_READ
////////////////////////////////////////////////////////////////////////////////////////

unsigned char EzportReadOneByte_READ(unsigned long EzportStartAddress)
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	unsigned long FlashStartAddress;

	unsigned char FlashStartAddressHigh;
	unsigned char FlashStartAddressMid;
	unsigned char FlashStartAddressLow;

	FlashStartAddress = EzportStartAddress & 0x000fffff;

	FlashStartAddressHigh = (unsigned char) (0xff & (FlashStartAddress >> 16));

	FlashStartAddressMid = (unsigned char) (0xff & (FlashStartAddress >> 8));

	FlashStartAddressLow = (unsigned char) (0xff & (FlashStartAddress));

	ftdi_usb_purge_rx_buffer(&FTDI_PORTA);

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x03;			//Send a byte of 0x03 to perform READ command

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x02;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressHigh;	//Send high byte of flash address
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressMid;	//Send mid byte of flash address
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressLow;	//Send low byte of flash address

	glOutputBufferFTDI[CountBytesToSend++] = 0x31;			//Command to send/receive byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte

	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Send empty byte

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	ftdi_read_data(&FTDI_PORTA, glInputBufferFTDI, 1);

	return glInputBufferFTDI[0] & 0xff;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportReadMultipleBytes_FAST_READ
////////////////////////////////////////////////////////////////////////////////////////

void EzportReadMultipleBytes_FAST_READ(unsigned long EzportStartAddress, unsigned int EzportNumberOfBytes)
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	unsigned long FlashStartAddress;

	unsigned char FlashStartAddressHigh;
	unsigned char FlashStartAddressMid;
	unsigned char FlashStartAddressLow;

	unsigned char EzportNumberOfBytesHigh;
	unsigned char EzportNumberOfBytesLow;

	unsigned int EzportReadBufferIndex;

	FlashStartAddress = EzportStartAddress & 0x000fffff;

	FlashStartAddressHigh = (unsigned char) (0xff & (FlashStartAddress >> 16));

	FlashStartAddressMid = (unsigned char) (0xff & (FlashStartAddress >> 8));

	FlashStartAddressLow = (unsigned char) (0xff & (FlashStartAddress));

	EzportNumberOfBytesHigh = (unsigned char) (0xff & (EzportNumberOfBytes >> 8));

	EzportNumberOfBytesLow = (unsigned char) (0xff & (EzportNumberOfBytes));

	ftdi_usb_purge_rx_buffer(&FTDI_PORTA);

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x0b;			//Send a byte of 0x0b to perform FAST READ command

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x02;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressHigh;	//Send high byte of flash address
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressMid;	//Send mid byte of flash address
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressLow;	//Send low byte of flash address

	glOutputBufferFTDI[CountBytesToSend++] = 0x31;				//Command to send/receive byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesLow;	//Set length to number of bytes
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesHigh;	//Set length to number of bytes

	for(EzportReadBufferIndex = 0; EzportReadBufferIndex < (EzportNumberOfBytes + 1); EzportReadBufferIndex++)
		{
		glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Send empty byte
		}

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	ftdi_read_data(&FTDI_PORTA, glInputBufferFTDI, EzportNumberOfBytes + 1);

	for(EzportReadBufferIndex = 0; EzportReadBufferIndex < EzportNumberOfBytes; EzportReadBufferIndex++)
		{
		KinetisEzportReadBufferData[EzportReadBufferIndex] = glInputBufferFTDI[EzportReadBufferIndex + 1];
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportSectionProgram_SP
////////////////////////////////////////////////////////////////////////////////////////

void EzportSectionProgram_SP(unsigned long EzportStartAddress, unsigned int EzportNumberOfBytes)
	{
	unsigned int CountBytesToSend;

	unsigned int BufferIndex;

	unsigned long FlashStartAddress;

	unsigned char FlashStartAddressHigh;
	unsigned char FlashStartAddressMid;
	unsigned char FlashStartAddressLow;

	unsigned char EzportNumberOfBytesHigh;
	unsigned char EzportNumberOfBytesLow;

	FlashStartAddress = EzportStartAddress & 0x000fffff;

	FlashStartAddressHigh = (unsigned char) (0xff & (FlashStartAddress >> 16));

	FlashStartAddressMid = (unsigned char) (0xff & (FlashStartAddress >> 8));

	FlashStartAddressLow = (unsigned char) (0xff & (FlashStartAddress));

	EzportNumberOfBytesHigh = (unsigned char) (((EzportNumberOfBytes - 1) >> 8) & 0xff);
	EzportNumberOfBytesLow = (unsigned char) ((EzportNumberOfBytes - 1) & 0xff);

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x02;			//Send a byte of 0x02 to perform SP command

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x02;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressHigh;	//Send high byte of flash address
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressMid;	//Send mid byte of flash address
	glOutputBufferFTDI[CountBytesToSend++] = FlashStartAddressLow;	//Send low byte of flash address

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;					//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesLow;		//Set length to number of bytes
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesHigh;		//Set length to number of bytes

	for (BufferIndex = 0; BufferIndex < EzportNumberOfBytes; BufferIndex++)
		{
		glOutputBufferFTDI[CountBytesToSend++] = KinetisFlashImageBufferData[FlashStartAddress + BufferIndex];//Send byte of data
		}

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	usleep(COMMAND_SP_USLEEP_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportSectorErase_SE
////////////////////////////////////////////////////////////////////////////////////////

void EzportSectorErase_SE(unsigned long EzportAddress)
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	unsigned long FlashAddress;

	unsigned char FlashAddressHigh;
	unsigned char FlashAddressMid;
	unsigned char FlashAddressLow;

	FlashAddress = EzportAddress & 0x000fffff;

	FlashAddressHigh = (unsigned char) (0xff & (FlashAddress >> 16));

	FlashAddressMid = (unsigned char) (0xff & (FlashAddress >> 8));

	FlashAddressLow = (unsigned char) (0xff & (FlashAddress));

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0xd8;			//Send a byte of 0xd8 to perform SE command

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x02;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = FlashAddressHigh;	//Send high byte of flash address
	glOutputBufferFTDI[CountBytesToSend++] = FlashAddressMid;	//Send mid byte of flash address
	glOutputBufferFTDI[CountBytesToSend++] = FlashAddressLow;	//Send low byte of flash address

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportBulkErase_BE
////////////////////////////////////////////////////////////////////////////////////////

void EzportBulkErase_BE(void)
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0xc7;			//Send a byte of 0xc7 to perform BE command

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	usleep(COMMAND_BE_USLEEP_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportReset_RESET
////////////////////////////////////////////////////////////////////////////////////////

void EzportReset_RESET(void)
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0xb9;			//Send a byte of 0xb9 to perform RESET command

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	usleep(COMMAND_RESET_USLEEP_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportWriteFCCOBRegisters_WRFCCOB
////////////////////////////////////////////////////////////////////////////////////////

void EzportWriteFCCOBRegisters_WRFCCOB()
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	unsigned int BufferIndex;

	unsigned int EzportNumberOfBytes;

	unsigned char EzportNumberOfBytesHigh;
	unsigned char EzportNumberOfBytesLow;

	EzportNumberOfBytes = 12;

	EzportNumberOfBytesHigh = (unsigned char) (((EzportNumberOfBytes - 1) >> 8) & 0xff);
	EzportNumberOfBytesLow = (unsigned char) ((EzportNumberOfBytes - 1) & 0xff);

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0xba;			//Send a byte of 0xba to perform WRFCCOB command

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;					//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesLow;		//Set length to number of bytes
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesHigh;		//Set length to number of bytes

	for (BufferIndex = 0; BufferIndex < EzportNumberOfBytes; BufferIndex++)
		{
		glOutputBufferFTDI[CountBytesToSend++] = KinetisFCCOBWriteBufferData[BufferIndex];	//Send byte of data
		}

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	usleep(COMMAND_WRFCCOB_USLEEP_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportReadFCCOBRegisters_FAST_RDFCCOB
/////////////////////////////////////////////////////////////////////////////////////////

void EzportReadFCCOBRegisters_FAST_RDFCCOB(unsigned int EzportNumberOfBytes)
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	unsigned char EzportNumberOfBytesHigh;
	unsigned char EzportNumberOfBytesLow;

	unsigned int EzportReadBufferIndex;

	EzportNumberOfBytesHigh = (unsigned char) (0xff & (EzportNumberOfBytes >> 8));

	EzportNumberOfBytesLow = (unsigned char) (0xff & (EzportNumberOfBytes));

	ftdi_usb_purge_rx_buffer(&FTDI_PORTA);

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0xbb;			//Send a byte of 0xbb to perform RDFCCOB command

	glOutputBufferFTDI[CountBytesToSend++] = 0x31;				//Command to send/receive byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesLow;	//Set length to number of bytes
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesHigh;	//Set length to number of bytes

	for(EzportReadBufferIndex = 0; EzportReadBufferIndex < (EzportNumberOfBytes + 1); EzportReadBufferIndex++)
		{
		glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Send empty byte
		}

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	ftdi_read_data(&FTDI_PORTA, glInputBufferFTDI, EzportNumberOfBytes + 1);

	for(EzportReadBufferIndex = 0; EzportReadBufferIndex < EzportNumberOfBytes; EzportReadBufferIndex++)
		{
		KinetisFCCOBReadBufferData[EzportReadBufferIndex] = glInputBufferFTDI[EzportReadBufferIndex + 1];
		}

	usleep(COMMAND_FAST_RDFCCOB_USLEEP_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportWriteFlexRAM_WRFLEXRAM
////////////////////////////////////////////////////////////////////////////////////////

void EzportWriteFlexRAM_WRFLEXRAM(unsigned long EzportAddress)
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	unsigned int BufferIndex;

	unsigned long FlexRAMAddress;

	unsigned char FlexRAMAddressHigh;
	unsigned char FlexRAMAddressMid;
	unsigned char FlexRAMAddressLow;

	unsigned int EzportNumberOfBytes;

	unsigned char EzportNumberOfBytesHigh;
	unsigned char EzportNumberOfBytesLow;

	FlexRAMAddress = EzportAddress & 0x000fffff;

	FlexRAMAddressHigh = (unsigned char) (0xff & (FlexRAMAddress >> 16));

	FlexRAMAddressMid = (unsigned char) (0xff & (FlexRAMAddress >> 8));

	FlexRAMAddressLow = (unsigned char) (0xff & (FlexRAMAddress));

	EzportNumberOfBytes = 4;

	EzportNumberOfBytesHigh = (unsigned char) (((EzportNumberOfBytes - 1) >> 8) & 0xff);
	EzportNumberOfBytesLow = (unsigned char) ((EzportNumberOfBytes - 1) & 0xff);

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0xbc;			//Send a byte of 0xbc to perform WRFLEXRAM command

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x02;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = FlexRAMAddressHigh;	//Send high byte of flex ram address
	glOutputBufferFTDI[CountBytesToSend++] = FlexRAMAddressMid;	//Send mid byte of flex ram address
	glOutputBufferFTDI[CountBytesToSend++] = FlexRAMAddressLow;	//Send low byte of flex ram address

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;						//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesLow;			//Set length to number of bytes
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesHigh;			//Set length to number of bytes

	for (BufferIndex = 0; BufferIndex < EzportNumberOfBytes; BufferIndex++)
		{
		glOutputBufferFTDI[CountBytesToSend++] = KinetisFlexRAMWriteBufferData[BufferIndex];	//Send byte of data
		}

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	usleep(COMMAND_WRFLEXRAM_USLEEP_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// EzportReadFlexRAM_FAST_RDFLEXRAM
////////////////////////////////////////////////////////////////////////////////////////

void EzportReadFlexRAM_FAST_RDFLEXRAM(unsigned long EzportAddress, unsigned int EzportNumberOfBytes)
	{
	unsigned char IndexFTDI;

	unsigned int CountBytesToSend;

	unsigned long FlexRAMAddress;

	unsigned char FlexRAMAddressHigh;
	unsigned char FlexRAMAddressMid;
	unsigned char FlexRAMAddressLow;

	unsigned char EzportNumberOfBytesHigh;
	unsigned char EzportNumberOfBytesLow;

	unsigned int EzportReadBufferIndex;

	FlexRAMAddress = EzportAddress & 0x000fffff;

	FlexRAMAddressHigh = (unsigned char) (0xff & (FlexRAMAddress >> 16));

	FlexRAMAddressMid = (unsigned char) (0xff & (FlexRAMAddress >> 8));

	FlexRAMAddressLow = (unsigned char) (0xff & (FlexRAMAddress));

	EzportNumberOfBytesHigh = (unsigned char) (0xff & (EzportNumberOfBytes >> 8));

	EzportNumberOfBytesLow = (unsigned char) (0xff & (EzportNumberOfBytes));

	ftdi_usb_purge_rx_buffer(&FTDI_PORTA);

	CountBytesToSend = 0;						//Clear output buffer

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xa8;			//1010 1000 DEC2,dec1,DEC0,cs_gp | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x08;			//dat 0000 1000 ezpcs,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to one byte
	glOutputBufferFTDI[CountBytesToSend++] = 0xbe;			//Send a byte of 0xbe to perform RDFLEXRAM command

	glOutputBufferFTDI[CountBytesToSend++] = 0x11;			//Command to send byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = 0x02;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Set length to three bytes
	glOutputBufferFTDI[CountBytesToSend++] = FlexRAMAddressHigh;	//Send high byte of flex ram address
	glOutputBufferFTDI[CountBytesToSend++] = FlexRAMAddressMid;	//Send mid byte of flex ram address
	glOutputBufferFTDI[CountBytesToSend++] = FlexRAMAddressLow;	//Send low byte of flex ram address

	glOutputBufferFTDI[CountBytesToSend++] = 0x31;				//Command to send/receive byte(s)
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesLow;	//Set length to number of bytes
	glOutputBufferFTDI[CountBytesToSend++] = EzportNumberOfBytesHigh;	//Set length to number of bytes

	for(EzportReadBufferIndex = 0; EzportReadBufferIndex < (EzportNumberOfBytes + 1); EzportReadBufferIndex++)
		{
		glOutputBufferFTDI[CountBytesToSend++] = 0x00;			//Send empty byte
		}

//	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
//	glOutputBufferFTDI[CountBytesToSend++] = 0xb8;			//1011 1000 DEC2,dec1,DEC0,CS_GP | CS_FPGA,miso,mosi,sck
//	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//1111 1011 DEC2,DEC1,DEC0,CS_GP | CS_FPGA,miso,MOSI,SCK

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	ftdi_read_data(&FTDI_PORTA, glInputBufferFTDI, EzportNumberOfBytes + 1);

	for(EzportReadBufferIndex = 0; EzportReadBufferIndex < EzportNumberOfBytes; EzportReadBufferIndex++)
		{
		KinetisFlexRAMReadBufferData[EzportReadBufferIndex] = glInputBufferFTDI[EzportReadBufferIndex + 1];
		}

	usleep(COMMAND_RDFLEXRAM_USLEEP_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// BitbangWritePortA
////////////////////////////////////////////////////////////////////////////////////////

void BitbangWritePortA(unsigned char BitbangDirection, unsigned char BitbangData)
	{
	int ReturnValue;

	unsigned char OutputBufferFTDI[8];			//Buffer to hold MPSSE commands and data to be sent to FT2232H

	ReturnValue = ftdi_set_bitmode(&FTDI_PORTA, BitbangDirection, BITMODE_BITBANG);
	if (ReturnValue < 0)
		{
		printf("Fail: Port A Set Bitmode error on ftdi\n");
		}

	OutputBufferFTDI[0] = BitbangData;

	ReturnValue = ftdi_write_data(&FTDI_PORTA, OutputBufferFTDI, 1);
	if (ReturnValue < 0)
		{
		printf("Fail: Port A Write Data error on ftdi\n");
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////
// BitbangWritePortB
////////////////////////////////////////////////////////////////////////////////////////

void BitbangWritePortB(unsigned char BitbangDirection, unsigned char BitbangData)
	{
	int ReturnValue;

	unsigned char OutputBufferFTDI[8];			//Buffer to hold MPSSE commands and data to be sent to FT2232H

	ReturnValue = ftdi_set_bitmode(&FTDI_PORTB, BitbangDirection, BITMODE_BITBANG);
	if (ReturnValue < 0)
		{
		printf("Fail: Port B Set Bitmode error on ftdi\n");
		}

	OutputBufferFTDI[0] = BitbangData;

	ReturnValue = ftdi_write_data(&FTDI_PORTB, OutputBufferFTDI, 1);
	if (ReturnValue < 0)
		{
		printf("Fail: Port B Write Data error on ftdi\n");
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////
// DetermineFileType
////////////////////////////////////////////////////////////////////////////////////////

unsigned char DetermineFileType()
	{
	unsigned char	FileType;

	char		FileBuffer[HEX_RECORD_LINE_SIZE];

	DetermineFile = fopen(EzportSourceFilename, "r");

	if (DetermineFile == NULL)
		{
		printf("\n");
		printf("Error: Programming file unable to be opened!\n");
		printf("\n");
		return FILE_TYPE_NONE;
		}

	fgets(FileBuffer, HEX_RECORD_LINE_SIZE, DetermineFile);

	if (FileBuffer[0] == 'S')
		{
		FileType =  FILE_TYPE_S_RECORD;
		}
	else if  (FileBuffer[0] == ':')
		{
		FileType = FILE_TYPE_INTEL_HEX;
		}
	else
		{
		FileType = FILE_TYPE_NONE;
		}

	fclose(DetermineFile);

	return FileType;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// LoadHexFileIntoFlashImageBuffer
////////////////////////////////////////////////////////////////////////////////////////

int LoadHexFileIntoFlashImageBuffer(unsigned char ClearFlashImageBuffer, unsigned char CodeTypeToLoad)
	{
	unsigned long	BufferIndex;

	char		LineIn[HEX_RECORD_LINE_SIZE];
	int		ByteAddress;
	int		NumberOfBytes;
	int		RecordType;
	int		DataBytes[256];

	int		ByteIndex;
	int		LineNumber = 1;

	int		MinAddress = KINETIS_FLASH_SIZE_IN_BYTES;
	int		MaxAddress = 0;

	int		IntelHexError;

	IntelHexFile = fopen(EzportSourceFilename, "r");

	if (IntelHexFile == NULL)
		{
		printf("\n");
		printf("Error: Programming file unable to be opened!\n");
		printf("\n");
		return FILE_FAILURE;
		}

//	AppGoAddress[0] = 0x00;
//	AppGoAddress[1] = 0x00;
//	AppGoAddress[2] = 0x00;
//	AppGoAddress[3] = 0x00;

	if (ClearFlashImageBuffer == FLASH_IMAGE_BUFFER_CLEAR)
		{
		for (BufferIndex = 0; BufferIndex < KINETIS_FLASH_SIZE_IN_BYTES; BufferIndex++)
			{
			KinetisFlashImageBufferData[BufferIndex] = 0xff;
			KinetisFlashImageBufferMask[BufferIndex] = 0x00;
			}
		}

	IntelHexError = INTEL_HEX_OK;
	IntelHexSegment = 0x0000;

	while (!feof(IntelHexFile) && !ferror(IntelHexFile))
		{
		LineIn[0] = '\0';

		fgets(LineIn, HEX_RECORD_LINE_SIZE, IntelHexFile);

		if (LineIn[strlen(LineIn) - 1] == '\n')
			{
			LineIn[strlen(LineIn) - 1] = '\0';
			}
		if (LineIn[strlen(LineIn) - 1] == '\r')
			{
			LineIn[strlen(LineIn) - 1] = '\0';
			}
		if (ParseHexLine(LineIn, DataBytes, &ByteAddress, &NumberOfBytes, &RecordType))
			{
			if (RecordType == 0)
				{
				for(ByteIndex = 0; ByteIndex <= (NumberOfBytes - 1); ByteIndex++)
					{

					IntelHexExtendedAddress = (IntelHexSegment * 16) + ByteAddress;

					KinetisFlashImageBufferData[IntelHexExtendedAddress] = DataBytes[ByteIndex] & 0xff;
					KinetisFlashImageBufferMask[IntelHexExtendedAddress] = 0x01;

					ByteAddress++;
					}
				}
			if (RecordType == 1)		// end of file
				{
				break;
				}
			if (RecordType == 2)		// extended segment address
				{
				IntelHexSegment = ((DataBytes[0] << 8) & 0xff00) | (DataBytes[1] & 0x00ff);
				}
			if (RecordType == 3)		// start segment address
				{
				}
			if (RecordType == 4)		// extended linear address
				{
				}
			if (RecordType == 5)		// start linear address
				{
				}
			}
		else
			{
			IntelHexError = INTEL_HEX_ERROR;
			}
		LineNumber++;
		}

	if (IntelHexError == INTEL_HEX_OK)
		{
		if (CodeTypeToLoad == CODE_TYPE_BOOT)
			{
			printf("Pass: Ezport Flash Boot programming file read correctly\n");
			}
		else if (CodeTypeToLoad == CODE_TYPE_APP)
			{
			printf("Pass: Ezport Flash App programming file read correctly\n");
			}
		else
			{
			printf("Pass: Ezport Flash programming file read correctly\n");
			}
		}
	else
		{
		if (CodeTypeToLoad == CODE_TYPE_BOOT)
			{
			printf("Fail: Ezport Flash Boot programming file not read correctly\n");
			}
		else if (CodeTypeToLoad == CODE_TYPE_APP)
			{
			printf("Fail: Ezport Flash App programming file not read correctly\n");
			}
		else
			{
			printf("Fail: Ezport Flash programming file not read correctly\n");
			}

		return FILE_FAILURE;
		}

	fclose(IntelHexFile);

	return FILE_SUCCESS;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// ParseHexLine
////////////////////////////////////////////////////////////////////////////////////////

int ParseHexLine(char *HexLine, int *DataBytes, int *ByteAddress, int *NumberOfBytes, int *RecordType)
// info only    char *HexLine;
// info only    int *ByteAddress;
// info only    int *NumberOfBytes;
// info only    int *RecordType;
// info only    int DataBytes[];
	{
	int	ByteSum;
	int	ByteLength;
	int	CheckSum;
	char	*DataString;
	
	*NumberOfBytes = 0;

	if (HexLine[0] != ':')				// line is not Intel Hex format
		{
		return 0;
		}

	if (strlen(HexLine) < 11)			// line is less than minumum length
		{
		return 0;
		}

	DataString = HexLine + 1;			// string of Intel Hex that starts after the colon

	if (!sscanf(DataString, "%02x", &ByteLength))	// gets number of data bytes in the line
		{
		return 0;
		}

	DataString += 2;				// string of Intex Hex that starts at the address field
	if ( strlen(HexLine) < (11 + (ByteLength * 2)) )
		{
		return 0;
		}

	if (!sscanf(DataString, "%04x", ByteAddress))	// gets address of Intel Hex line
		{
		return 0;
		}

	DataString += 4;
	if (!sscanf(DataString, "%02x", RecordType))	// gets record type of Intel Hex line
		{
		return 0;
		}

	DataString += 2;
	ByteSum = (ByteLength & 0xff) + ((*ByteAddress >> 8) & 0xff) + (*ByteAddress & 0xff) + (*RecordType & 0xff);

	while(*NumberOfBytes != ByteLength)
		{
		if (!sscanf(DataString, "%02x", &DataBytes[*NumberOfBytes]))	//get data byte of Intel Hex line
			{
			return 0;
			}
		DataString += 2;
		ByteSum += DataBytes[*NumberOfBytes] & 0xff;
		(*NumberOfBytes)++;
		if (*NumberOfBytes >= 256)
			{
			return 0;
			}
		}

	if (!sscanf(DataString, "%02x", &CheckSum))		// gets checksum of Intel Hex line
		{
		return 0;
		}

	if ( ((ByteSum & 0xff) + (CheckSum & 0xff)) & 0xff )
		{
		return 0; /* checksum error */
		}

	return 1;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// LoadSrecFileIntoFlashImageBuffer
////////////////////////////////////////////////////////////////////////////////////////

int LoadSrecFileIntoFlashImageBuffer(unsigned char ClearFlashImageBuffer, unsigned char CodeTypeToLoad)
	{
	FreescaleSRecord	FreeSRecord;

	unsigned long	BufferIndex;

	FreescaleSRecordFile = fopen(EzportSourceFilename, "r");

	if (FreescaleSRecordFile == NULL)
		{
		printf("\n");
		printf("Error: Programming file unable to be opened!\n");
		printf("\n");
		return FILE_FAILURE;
		}

	AppGoAddress[0] = 0x00;
	AppGoAddress[1] = 0x00;
	AppGoAddress[2] = 0x00;
	AppGoAddress[3] = 0x00;

	if (ClearFlashImageBuffer == FLASH_IMAGE_BUFFER_CLEAR)
		{
		for (BufferIndex = 0; BufferIndex < KINETIS_FLASH_SIZE_IN_BYTES; BufferIndex++)
			{
			KinetisFlashImageBufferData[BufferIndex] = 0xff;
			KinetisFlashImageBufferMask[BufferIndex] = 0x00;
			}
		}

	while (Read_FreescaleSRecord(&FreeSRecord, FreescaleSRecordFile) == SRECORD_OK)
		{
		RecordType = FreeSRecord.Type;
		RecordDataLength = FreeSRecord.DataLength;
		RecordAddress = FreeSRecord.Address;

		switch(RecordType)
			{
			case SRECORD_TYPE_S1:
			case SRECORD_TYPE_S2:
			case SRECORD_TYPE_S3:
				for (RecordIndex = 0; RecordIndex < RecordDataLength; RecordIndex++)
					{
					RecordData = FreeSRecord.Data[RecordIndex];
					RecordExtendedAddress = RecordAddress + RecordIndex;

					if (RecordExtendedAddress < KINETIS_FLASH_SIZE_IN_BYTES)
						{
						KinetisFlashImageBufferData[RecordExtendedAddress]  = RecordData; 
						KinetisFlashImageBufferMask[RecordExtendedAddress]  = 0x01; 
						}
					else
						{
						printf("\n");
						printf("Error: Programming file maximum address exceeded.\n");
						printf("\n");
						return FILE_FAILURE;
						break;
						}
					}
				break;

			case SRECORD_TYPE_S7:
			case SRECORD_TYPE_S8:
			case SRECORD_TYPE_S9:
				AppGoAddress[0]  = (RecordAddress >> 24) & 0xff; 
				AppGoAddress[1]  = (RecordAddress >> 16) & 0xff; 
				AppGoAddress[2]  = (RecordAddress >> 8) & 0xff; 
				AppGoAddress[3]  = (RecordAddress) & 0xff; 
				break;

			default:
				break;
			}
		}

	if (FreeSRecord.Error == SRECORD_OK)
		{
		if (CodeTypeToLoad == CODE_TYPE_BOOT)
			{
			printf("Pass: Ezport Flash Boot programming file read correctly\n");
			}
		else if (CodeTypeToLoad == CODE_TYPE_APP)
			{
			printf("Pass: Ezport Flash App programming file read correctly\n");
			}
		else
			{
			printf("Pass: Ezport Flash programming file read correctly\n");
			}
		}
	else
		{
		if (CodeTypeToLoad == CODE_TYPE_BOOT)
			{
			printf("Fail: Ezport Flash Boot programming file not read correctly\n");
			}
		else if (CodeTypeToLoad == CODE_TYPE_APP)
			{
			printf("Fail: Ezport Flash App programming file not read correctly\n");
			}
		else
			{
			printf("Fail: Ezport Flash programming file not read correctly\n");
			}

		return FILE_FAILURE;
		}

	fclose(FreescaleSRecordFile);

	return FILE_SUCCESS;
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FreescaleSHexRecord_Address_Lengths
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static int16_t FreescaleSRecord_Address_Lengths[] =
	{
	4, // S0
	4, // S1
	6, // S2
	8, // S3
	8, // S4
	4, // S5
	6, // S6
	8, // S7
	6, // S8
	4, // S9
	};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Read_FreescaleSRecord
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int16_t Read_FreescaleSRecord(FreescaleSRecord *SRecord, FILE *FileIn)
	{
	int8_t RecordBuffer[SRECORD_RECORD_BUFF_SIZE];

// A temporary buffer to hold ASCII hex encoded data, set to the maximum length we would ever need
	int8_t HexBuffer[SRECORD_MAX_ADDRESS_LEN + 1];

	int16_t AsciiAddressLength;
	int16_t AsciiDataLength;
	int16_t DataOffset;
	int16_t FieldDataCount;
	int16_t ReadIndex;
	
// Check our record pointer and file pointer
	if (SRecord == NULL || FileIn == NULL)
		{
		SRecord->Error = SRECORD_ERROR_INVALID_ARGUMENTS;
		return SRECORD_ERROR_INVALID_ARGUMENTS;
		}

	if (fgets(RecordBuffer, SRECORD_RECORD_BUFF_SIZE, FileIn) == NULL)
		{
// In case we hit EOF, don't report a file error
		if (feof(FileIn) != 0)
			{
			SRecord->Error = SRECORD_NO_ERROR;
			return SRECORD_ERROR_EOF;
			}
		else
			{
			printf("Read_FreescaleSRecord error: SRECORD_ERROR_FILE\n");
			SRecord->Error = SRECORD_ERROR_FILE;
			return SRECORD_ERROR_FILE;
			}
		}

// Null-terminate the string at the first sign of a \r or \n
	for (ReadIndex = 0; ReadIndex < (int16_t)strlen(RecordBuffer); ReadIndex++)
		{
		if (RecordBuffer[ReadIndex] == '\r' || RecordBuffer[ReadIndex] == '\n')
			{
			RecordBuffer[ReadIndex] = 0;
			break;
			}
		}

// Check if we hit a newline
	if (strlen(RecordBuffer) == 0)
		{
		SRecord->Error = SRECORD_NO_ERROR;
		return SRECORD_ERROR_NEWLINE;
		}

// Size check for type and count fields
	if (strlen(RecordBuffer) < SRECORD_TYPE_LEN + SRECORD_COUNT_LEN)
		{
		printf("Read_FreescaleSRecord error: SRECORD_ERROR_INVALID_RECORD : TYPE / COUNT FIELDS VALIDITY CHECK\n");
		SRecord->Error = SRECORD_ERROR_INVALID_RECORD;
		return SRECORD_ERROR_INVALID_RECORD;
		}

// Check for the S-Record start code at the beginning of every record
	if (RecordBuffer[SRECORD_START_CODE_OFFSET] != SRECORD_START_CODE)
		{
		printf("Read_FreescaleSRecord error: SRECORD_ERROR_INVALID_RECORD : START CODE VALIDITY CHECK\n");
		SRecord->Error = SRECORD_ERROR_INVALID_RECORD;
		return SRECORD_ERROR_INVALID_RECORD;
		}

// Copy the ASCII hex encoding of the type field into HexBuffer, convert it into a usable integer
	strncpy(HexBuffer, RecordBuffer + SRECORD_TYPE_OFFSET, SRECORD_TYPE_LEN);

	HexBuffer[SRECORD_TYPE_LEN] = 0;

	SRecord->Type = strtol(HexBuffer, (char **)NULL, 16);
	
// Copy the ASCII hex encoding of the count field into HexBuffer, convert it to a usable integer
	strncpy(HexBuffer, RecordBuffer + SRECORD_COUNT_OFFSET, SRECORD_COUNT_LEN);

	HexBuffer[SRECORD_COUNT_LEN] = 0;

	FieldDataCount = strtol(HexBuffer, (char **)NULL, 16);
	
// Check that our S-Record type is valid
	if (SRecord->Type < SRECORD_TYPE_S0 || SRecord->Type > SRECORD_TYPE_S9)
		{
		printf("Read_FreescaleSRecord error: SRECORD_ERROR_INVALID_RECORD : S-RECORD VALIDITY CHECK\n");
		SRecord->Error = SRECORD_ERROR_INVALID_RECORD;
		return SRECORD_ERROR_INVALID_RECORD;
		}

// Get the ASCII hex address length of this particular S-Record type
	AsciiAddressLength = FreescaleSRecord_Address_Lengths[SRecord->Type];
	
// Size check for address field
	if (strlen(RecordBuffer) < (uint16_t)(SRECORD_ADDRESS_OFFSET + AsciiAddressLength))
		{
		printf("Read_FreescaleSRecord error: SRECORD_ERROR_INVALID_RECORD : ADDRESS VALIDITY CHECK\n");
		SRecord->Error = SRECORD_ERROR_INVALID_RECORD;
		return SRECORD_ERROR_INVALID_RECORD;
		}

// Copy the ASCII hex encoding of the count field into hexBuff, convert it to a usable integer
	strncpy(HexBuffer, RecordBuffer + SRECORD_ADDRESS_OFFSET, AsciiAddressLength);

	HexBuffer[AsciiAddressLength] = 0;

	SRecord->Address = strtol(HexBuffer, (char **)NULL, 16);
	
// Compute the ASCII hex data length by subtracting the remaining field lengths from the S-Record 
// count field (times 2 to account for the number of characters used in ASCII hex encoding)
	AsciiDataLength = (FieldDataCount * 2) - AsciiAddressLength - SRECORD_CHECKSUM_LEN;

// Bailout if we get an invalid data length
	if (AsciiDataLength < 0 || AsciiDataLength > SRECORD_MAX_DATA_LEN)
		{
		printf("Read_FreescaleSRecord error: SRECORD_ERROR_INVALID_RECORD : DATA LENGTH VALIDITY CHECK\n");
		SRecord->Error = SRECORD_ERROR_INVALID_RECORD;
		return SRECORD_ERROR_INVALID_RECORD;
		}

// Size check for final data field and checksum field
	if (strlen(RecordBuffer) < (uint16_t)(SRECORD_ADDRESS_OFFSET + AsciiAddressLength + AsciiDataLength + SRECORD_CHECKSUM_LEN))
		{
		printf("Read_FreescaleSRecord error: SRECORD_ERROR_INVALID_RECORD : CHECKSUM FIELD VALIDITY CHECK\n");
		SRecord->Error = SRECORD_ERROR_INVALID_RECORD;
		return SRECORD_ERROR_INVALID_RECORD;
		}

	DataOffset = SRECORD_ADDRESS_OFFSET + AsciiAddressLength;
	
// Loop through each ASCII hex byte of the data field, pull it out into HexBuffer,
// convert it and store the result in the data buffer of the S-Record
	for (ReadIndex = 0; ReadIndex < (AsciiDataLength / 2); ReadIndex++)
		{
// Times two i because every byte is represented by two ASCII hex characters
		strncpy(HexBuffer, RecordBuffer + DataOffset + (2 * ReadIndex), SRECORD_ASCII_HEX_BYTE_LEN);

		HexBuffer[SRECORD_ASCII_HEX_BYTE_LEN] = 0;

		SRecord->Data[ReadIndex] = strtol(HexBuffer, (char **)NULL, 16);
		}

// Real data len is divided by two because every byte is represented by two ASCII hex characters
	SRecord->DataLength = AsciiDataLength / 2;
	
// Copy out the checksum ASCII hex encoded byte, and convert it back to a usable integer
	strncpy(HexBuffer, RecordBuffer + DataOffset + AsciiDataLength, SRECORD_CHECKSUM_LEN);

	HexBuffer[SRECORD_CHECKSUM_LEN] = 0;

	SRecord->Checksum = strtol(HexBuffer, (char **)NULL, 16);

	if (SRecord->Checksum != Checksum_FreescaleSRecord(SRecord))
		{
		printf("Read_FreescaleSRecord error: SRECORD_ERROR_INVALID_RECORD : CHECKSUM ERROR\n");
		SRecord->Error = SRECORD_ERROR_INVALID_RECORD;
		return SRECORD_ERROR_INVALID_RECORD;
		}

	SRecord->Error = SRECORD_OK;

	return SRECORD_OK;
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Checksum_FreescaleSRecord
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t Checksum_FreescaleSRecord(const FreescaleSRecord *SRecord)
	{
	uint8_t CalcChecksum;

	int16_t FieldDataCount;

	int16_t ChecksumIndex;
	
// Compute the record count, address and checksum lengths are halved because record count
// is the number of bytes left in the record, not the length of the ASCII hex representation
	FieldDataCount = (FreescaleSRecord_Address_Lengths[SRecord->Type] / 2) + SRecord->DataLength + (SRECORD_CHECKSUM_LEN / 2);

// Add the count, address, and data fields together
	CalcChecksum = FieldDataCount;

// Add each byte of the address individually
	CalcChecksum += (uint8_t)(SRecord->Address & 0x000000FF);
	CalcChecksum += (uint8_t)((SRecord->Address & 0x0000FF00) >> 8);
	CalcChecksum += (uint8_t)((SRecord->Address & 0x00FF0000) >> 16);
	CalcChecksum += (uint8_t)((SRecord->Address & 0xFF000000) >> 24);

	for (ChecksumIndex = 0; ChecksumIndex < SRecord->DataLength; ChecksumIndex++)
		{
		CalcChecksum += SRecord->Data[ChecksumIndex];
		}

// One's complement the checksum
	CalcChecksum = ~CalcChecksum;
	
	return CalcChecksum;
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ClearKinetisEzportReadBufferData
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ClearKinetisEzportReadBufferData(unsigned char BufferValue)
	{
	unsigned long ClearIndex;

	for (ClearIndex = 0; ClearIndex < (KINETIS_READ_BUFFER_SIZE_IN_BYTES); ClearIndex++)
		{
		KinetisEzportReadBufferData[ClearIndex] = BufferValue;
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////
// FTDISetupEzportReset
////////////////////////////////////////////////////////////////////////////////////////

int FTDISetupEzportReset(void)
	{
	int FTDIStatus;

	unsigned int FTDIClockDivisor = 0x0000;		//Value of clock divisor, Frequency = 60/((1+0x0000)*2) (MHz) = 30MHz

	unsigned int dwCount;

	if (ftdi_init(&FTDI_PORTA) < 0)
		{
		fprintf(stderr, "Port A init failed\n");
		return FTDI_FAILURE;
		}

	ftdi_set_interface(&FTDI_PORTA, INTERFACE_A);

	if ( (FTDIStatus = ftdi_usb_open(&FTDI_PORTA, FTDI_VENDOR_ID, FTDI_PRODUCT_ID)) < 0 )
		{
		fprintf(stderr, "Error: Port A unable to open FTDI device %d (%s)\n", FTDIStatus, ftdi_get_error_string(&FTDI_PORTA) );
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_usb_reset(&FTDI_PORTA);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A reset error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTA, 0, 0);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A set bitmode error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTA, 0x0, BITMODE_BITBANG);   //all pins are inputs
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port A bitmode error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	if (ftdi_init(&FTDI_PORTB) < 0)
		{
		fprintf(stderr, "Port B init failed\n");
		return FTDI_FAILURE;
		}

	ftdi_set_interface(&FTDI_PORTB, INTERFACE_B);

	if ( (FTDIStatus = ftdi_usb_open(&FTDI_PORTB, FTDI_VENDOR_ID, FTDI_PRODUCT_ID)) < 0 )
		{
		fprintf(stderr, "Error: Port B unable to open FTDI device %d (%s)\n", FTDIStatus, ftdi_get_error_string(&FTDI_PORTB) );
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_usb_reset(&FTDI_PORTB);
	if (FTDIStatus < 0)
		{
		printf("Error: Port B reset error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTB, 0, 0);
	if (FTDIStatus < 0)
		{
		printf("Error: Port B set bitmode error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTB, 0x0, BITMODE_BITBANG);   //all pins are inputs
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B bitmode error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	return FTDI_SUCCESS;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// FTDISetupEzportProgram
////////////////////////////////////////////////////////////////////////////////////////

int FTDISetupEzportProgram(void)
	{
	int FTDIStatus;

	unsigned int FTDIClockDivisor = 0x0005;		//Value of clock divisor, Frequency = 60/((1+0x0005)*2) (MHz) = 5MHz

	unsigned int dwCount;

	unsigned char bCommandEchod = 0;

	unsigned char latency;
	unsigned int write_chunksize;
	unsigned int read_chunksize;

	unsigned int CountBytesToSend;

	CountBytesToSend = 0;					//Clear output buffer

// INTERFACE A
	FTDIStatus = ftdi_usb_reset(&FTDI_PORTA);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A reset error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_usb_purge_rx_buffer(&FTDI_PORTA);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A purge rx buffer error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_write_data_set_chunksize(&FTDI_PORTA, 2048+1024);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A write set chunksize error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_read_data_set_chunksize(&FTDI_PORTA, 512);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A read set chunksize error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_event_char(&FTDI_PORTA, 0, 0);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A set event error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_error_char(&FTDI_PORTA, 0, 0);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A set error error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_latency_timer(&FTDI_PORTA, 1);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A set latency timer error on FTDI device\n");
		return FTDI_FAILURE;
		}

	glOutputBufferFTDI[0] = 0xff;
	FTDIStatus = ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, 1);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A write data error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTA, 0xff, BITMODE_BITBANG);   //all pins are outputs
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port A bitmode error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTA, 0xfb, BITMODE_MPSSE);
	if (FTDIStatus < 0)
		{
		printf("Error: Port A set bitmode error on FTDI device\n");
		return FTDI_FAILURE;
		}

	glOutputBufferFTDI[CountBytesToSend++] = 0xAA;			//Add bad command 'AA'

	FTDIStatus = ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	do
		{
		FTDIStatus = ftdi_read_data(&FTDI_PORTA, glInputBufferFTDI, 512);
		} while (FTDIStatus == 0);

	dwNumBytesRead = FTDIStatus;

	for (dwCount = 0; dwCount < dwNumBytesRead - 1; dwCount++)	//Check if bad command and echo command received
		{
		if ((glInputBufferFTDI[dwCount] == 0xFA) && (glInputBufferFTDI[dwCount+1] == 0xAA))
			{
			bCommandEchod = 1;
			break;
			}
		}

	if (bCommandEchod == 0)
		{
		printf("Error: Port A receive echo command error on FTDI device (SetupEzportProgram)\n");
		return FTDI_FAILURE;
		}

//Configure the MPSSE settings for ezport communication
	CountBytesToSend = 0;					//Clear output buffer

	glOutputBufferFTDI[CountBytesToSend++] = 0x8A;		//Ensure disable clock divide by 5 for 60Mhz master clock
	glOutputBufferFTDI[CountBytesToSend++] = 0x97;		//Ensure turn off adaptive clocking
	glOutputBufferFTDI[CountBytesToSend++] = 0x8D;		//Disable 3 phase data clock

	FTDIStatus = ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	CountBytesToSend = 0;					//Clear output buffer

	glOutputBufferFTDI[CountBytesToSend++] = 0x80;			//Command to set value / direction
	glOutputBufferFTDI[CountBytesToSend++] = 0x88;			//dat 1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	glOutputBufferFTDI[CountBytesToSend++] = 0xfb;			//dir 1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	glOutputBufferFTDI[CountBytesToSend++] = 0x86;					//Command to set clock divisor
	glOutputBufferFTDI[CountBytesToSend++] = FTDIClockDivisor & 0xFF;		//Set 0xValueL of clock divisor
	glOutputBufferFTDI[CountBytesToSend++] = (FTDIClockDivisor >> 8) & 0xFF;	//Set 0xValueH of clock divisor

	FTDIStatus = ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	CountBytesToSend = 0;						//Clear output buffer

	glOutputBufferFTDI[CountBytesToSend++] = 0x85;			//Command to turn off loop back of TDI/TDO connection

	FTDIStatus = ftdi_write_data(&FTDI_PORTA, glOutputBufferFTDI, CountBytesToSend);

	CountBytesToSend = 0;						//Clear output buffer

// INTERFACE B
	FTDIStatus = ftdi_usb_reset(&FTDI_PORTB);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B reset error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_usb_purge_rx_buffer(&FTDI_PORTB);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B purge rx error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_write_data_set_chunksize(&FTDI_PORTB, 4);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B write chunksize error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_read_data_set_chunksize(&FTDI_PORTB, 4);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B read chunksize error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_event_char(&FTDI_PORTB, 0, 0);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B event char error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_error_char(&FTDI_PORTB, 0, 0);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B error char error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_latency_timer(&FTDI_PORTB, 16);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B latency timer error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	glOutputBufferFTDI[0] = 0xff;
	FTDIStatus = ftdi_write_data(&FTDI_PORTB, glOutputBufferFTDI, 1);
	if (FTDIStatus < 0)
		{
		printf("Error: Port B write data error on FTDI device\n");
		return FTDI_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTB, 0xff, BITMODE_BITBANG);   //all pins are outputs
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B bitmode error on FTDI device\n");
		printf("\n");
		return FTDI_FAILURE;
		}

	return FTDI_SUCCESS;
	}

