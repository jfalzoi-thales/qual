#!/bin/bash

ok() {
        echo -e "\033[032mOK\t0x$1 Detected\033[0m"
}

failed() {
        echo -e "\033[031mFailed\t0x$1 Missing\033[0m"
	exit 1
}

print_dev_list() {
	echo
	echo Device List :
	echo -e "-01 -02"
	echo -e "SSD IFE\tAddress\t\tDescription"
	echo -e "--- ---\t----------\t-------------"
	echo -e " X   X\t0x4c/0x77\tTemp Sensor1"
	echo -e "     X\t0x4d/0x77\tTemp Sensor2"
	echo -e "     X\t0x4e/0x77\tVolt Sensor1"
	echo -e " X   X\t0x4f/0x77\tVolt Sensor2"
	echo -e "     X\t0x50\t\tEEPROM"
	echo -e "     X\t0x61\t\tFPGA"
	echo -e "     X\t0x70\t\tI/O Expander"
	echo -e " X   X\t0x73\t\tI2C MUX"
	echo
	i2cdetect -y 7
	echo
}

if [[ "$1" = "IFE" || "$1" = "ife" ]]; then
	ife_i2c_sel 0
	driver_load.sh
	i2cset -y 7 0x73 0x7f
	print_dev_list
	i2c_lst=`i2cdetect -y 7`
	[[ -z `echo $i2c_lst | grep 4c` ]] && failed 4C || ok 4C
	[[ -z `echo $i2c_lst | grep 4d` ]] && failed 4D || ok 4D
	[[ -z `echo $i2c_lst | grep 4e` ]] && failed 4E || ok 4E
	[[ -z `echo $i2c_lst | grep 4f` ]] && failed 4F || ok 4F
	[[ -z `echo $i2c_lst | grep 50` ]] && failed 50 || ok 50
	[[ -z `echo $i2c_lst | grep 61` ]] && failed 61 || ok 61
	[[ -z `echo $i2c_lst | grep 70` ]] && failed 70 || ok 70
	[[ -z `echo $i2c_lst | grep 73` ]] && failed 73 || ok 73
	[[ -z `echo $i2c_lst | grep 77` ]] && failed 77 || ok 77
	i2cset -y 7 0x73 0x20
elif [[ "$1" = "SSD" || "$1" = "ssd" ]]; then
	driver_load.sh
	i2cset -y 7 0x73 0x7f
	print_dev_list
	i2c_lst=`i2cdetect -y 7`
	[[ -z `echo $i2c_lst | grep 4c` ]] && failed 4C || ok 4C
	[[ -z `echo $i2c_lst | grep 4f` ]] && failed 4F || ok 4F
	[[ -z `echo $i2c_lst | grep 73` ]] && failed 73 || ok 73
	[[ -z `echo $i2c_lst | grep 77` ]] && failed 77 || ok 77
	i2cset -y 7 0x73 0x20
else
	echo "Usage: fvt_i2c.sh {ife|IFE | ssd|SSD}"
	echo "  fvt_i2c.sh ife"
	echo "  fvt_i2c.sh ssd"
fi


