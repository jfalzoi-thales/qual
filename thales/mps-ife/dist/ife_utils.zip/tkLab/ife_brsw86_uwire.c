#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <ftdi.h>

#include <unistd.h>

// This program is used to run the ftdi board.
//
// To compile this program, use the following command line:
//
// gcc -o ife_brsw86_uwire ife_brsw86_uwire.c $(pkg-config --cflags --libs libftdi)

#define FTDI_MINI_VENDOR_ID   			0x0403			// FTDI mini vendor id
#define FTDI_MINI_PRODUCT_ID  			0x6011			// FTDI mini product id

#define FTDI_INTERFACE				INTERFACE_A

#define ACK_FAILURE				1
#define ACK_SUCCESS				0

#define FTDI_FAILURE				1
#define FTDI_SUCCESS				0

#define UWIRE_FAILURE				1
#define UWIRE_SUCCESS				0

#define FILE_FAILURE				1
#define FILE_SUCCESS				0

#define FILE_READ_BIN				2
#define FILE_READ_SREC				1
#define FILE_READ_NO				0

#define UWIRE_CS_HIGH				1
#define UWIRE_CS_LOW				0

#define UWIRE_CHIP_SELECT_BRSW			2
#define UWIRE_CHIP_SELECT_CONFIG		1
#define UWIRE_CHIP_SELECT_NONE			0

#define UWIRE_OPCODE_EWDS			4
#define UWIRE_OPCODE_ERASE			3
#define UWIRE_OPCODE_READ			2
#define UWIRE_OPCODE_WRITE			1
#define UWIRE_OPCODE_EWEN			0

#define FTDI_UWIRE_DISABLE			1
#define FTDI_UWIRE_ENABLE			0

#define SETUP_RETRY				2
#define SETUP_FAILURE				1
#define SETUP_SUCCESS				0

#define WORD_PROGRAM_NECESSARY			1
#define WORD_PROGRAM_NOT_NECESSARY		0

#define BULK_ERASE_USLEEP_MICROSECONDS		100

#define USLEEP_STATUS_MICROSECONDS		500			// initial value 100000

#define WRITE_USLEEP_TEN_MILLISECONDS		10000
#define ERASE_USLEEP_TEN_MILLISECONDS		10000
#define READ_USLEEP_ONE_MILLISECONDS		1000
#define EWEN_USLEEP_ONE_MILLISECONDS		1000

#define NONVOL_MEMORY_SIZE_IN_LOCATIONS		1024			// Size of nonvolatile memory in memory locations

#define NONVOL_MEMORY_SIZE_IN_BYTES		2048			// Size of nonvolatile memory in memory bytes

#define DOT_PROGRESS_INTERVAL			128
//////////////////////////////////////////////////////////////////
// Define the global variables and const variables
//////////////////////////////////////////////////////////////////

unsigned char FileReadFlag;

int16_t FTDIStatus;

uint16_t CountBytesToSend;

uint8_t InputBuffer[1024];

uint8_t OutputBuffer[1024];

int8_t UwireSourceFilename[64];

int8_t BinaryOutputFilename[64];

uint8_t UwireEnableFlag;

uint32_t NonvolWriteBufferIndex;

uint8_t NonvolWriteBuffer_Bits8[NONVOL_MEMORY_SIZE_IN_BYTES];

uint32_t NonvolReadBufferIndex;

uint8_t NonvolReadBuffer_Bits8[NONVOL_MEMORY_SIZE_IN_BYTES];

uint16_t NonvolDisplayAddress;

uint8_t UwireChipSelection;

uint16_t dwClockDivisor = 0x0001;	//	1	Value of clock divisor, SCL Frequency = 60/((1+0x0001)*2) (MHz) = 15.0MHz
//uint16_t dwClockDivisor = 0x0002;	//	2	Value of clock divisor, SCL Frequency = 60/((1+0x0002)*2) (MHz) = 10.0MHz
//uint16_t dwClockDivisor = 0x0003;	//	3	Value of clock divisor, SCL Frequency = 60/((1+0x0003)*2) (MHz) = 7.50MHz
//uint16_t dwClockDivisor = 0x0004;	//	4	Value of clock divisor, SCL Frequency = 60/((1+0x0004)*2) (MHz) = 6.00MHz
//uint16_t dwClockDivisor = 0x0005;	//	5	Value of clock divisor, SCL Frequency = 60/((1+0x0005)*2) (MHz) = 5.00MHz
//uint16_t dwClockDivisor = 0x0006;	//	6	Value of clock divisor, SCL Frequency = 60/((1+0x0006)*2) (MHz) = 4.29MHz
//uint16_t dwClockDivisor = 0x0007;	//	7	Value of clock divisor, SCL Frequency = 60/((1+0x0007)*2) (MHz) = 3.75MHz
//uint16_t dwClockDivisor = 0x0008;	//	8	Value of clock divisor, SCL Frequency = 60/((1+0x0008)*2) (MHz) = 3.33MHz
//uint16_t dwClockDivisor = 0x0009;	//	9	Value of clock divisor, SCL Frequency = 60/((1+0x0009)*2) (MHz) = 3.00MHz
//uint16_t dwClockDivisor = 0x000a;	//	10	Value of clock divisor, SCL Frequency = 60/((1+0x000a)*2) (MHz) = 2.73MHz
//uint16_t dwClockDivisor = 0x000b;	//	11	Value of clock divisor, SCL Frequency = 60/((1+0x000b)*2) (MHz) = 2.50MHz
//uint16_t dwClockDivisor = 0x000c;	//	12	Value of clock divisor, SCL Frequency = 60/((1+0x000c)*2) (MHz) = 2.31MHz
//uint16_t dwClockDivisor = 0x000d;	//	13	Value of clock divisor, SCL Frequency = 60/((1+0x000d)*2) (MHz) = 2.14MHz
//uint16_t dwClockDivisor = 0x000e;	//	14	Value of clock divisor, SCL Frequency = 60/((1+0x000e)*2) (MHz) = 2.00MHz
//uint16_t dwClockDivisor = 0x000f;	//	15	Value of clock divisor, SCL Frequency = 60/((1+0x000f)*2) (MHz) = 1.88MHz
//uint16_t dwClockDivisor = 0x0010;	//	16	Value of clock divisor, SCL Frequency = 60/((1+0x0010)*2) (MHz) = 1.76MHz
//uint16_t dwClockDivisor = 0x0011;	//	17	Value of clock divisor, SCL Frequency = 60/((1+0x0011)*2) (MHz) = 1.67MHz
//uint16_t dwClockDivisor = 0x0012;	//	18	Value of clock divisor, SCL Frequency = 60/((1+0x0012)*2) (MHz) = 1.58MHz
//uint16_t dwClockDivisor = 0x0013;	//	19	Value of clock divisor, SCL Frequency = 60/((1+0x0013)*2) (MHz) = 1.50MHz
//uint16_t dwClockDivisor = 0x0014;	//	20	Value of clock divisor, SCL Frequency = 60/((1+0x0014)*2) (MHz) = 1.43MHz
//uint16_t dwClockDivisor = 0x0015;	//	21	Value of clock divisor, SCL Frequency = 60/((1+0x0015)*2) (MHz) = 1.36MHz
//uint16_t dwClockDivisor = 0x0016;	//	22	Value of clock divisor, SCL Frequency = 60/((1+0x0016)*2) (MHz) = 1.30MHz
//uint16_t dwClockDivisor = 0x0017;	//	23	Value of clock divisor, SCL Frequency = 60/((1+0x0017)*2) (MHz) = 1.25MHz
//uint16_t dwClockDivisor = 0x0018;	//	24	Value of clock divisor, SCL Frequency = 60/((1+0x0018)*2) (MHz) = 1.20MHz
//uint16_t dwClockDivisor = 0x0019;	//	25	Value of clock divisor, SCL Frequency = 60/((1+0x0019)*2) (MHz) = 1.15MHz
//uint16_t dwClockDivisor = 0x001a;	//	26	Value of clock divisor, SCL Frequency = 60/((1+0x001a)*2) (MHz) = 1.11MHz
//uint16_t dwClockDivisor = 0x001b;	//	27	Value of clock divisor, SCL Frequency = 60/((1+0x001b)*2) (MHz) = 1.07MHz
//uint16_t dwClockDivisor = 0x001c;	//	28	Value of clock divisor, SCL Frequency = 60/((1+0x001c)*2) (MHz) = 1.03MHz
//uint16_t dwClockDivisor = 0x001d;	//	29	Value of clock divisor, SCL Frequency = 60/((1+0x001d)*2) (MHz) = 1.00MHz
//uint16_t dwClockDivisor = 0x001e;	//	30	Value of clock divisor, SCL Frequency = 60/((1+0x001e)*2) (MHz) = 0.97MHz
//uint16_t dwClockDivisor = 0x001f;	//	31	Value of clock divisor, SCL Frequency = 60/((1+0x001f)*2) (MHz) = 0.94MHz
//uint16_t dwClockDivisor = 0x0020;	//	32	Value of clock divisor, SCL Frequency = 60/((1+0x0020)*2) (MHz) = 0.91MHz
//uint16_t dwClockDivisor = 0x0021;	//	33	Value of clock divisor, SCL Frequency = 60/((1+0x0021)*2) (MHz) = 0.88MHz
//uint16_t dwClockDivisor = 0x0022;	//	34	Value of clock divisor, SCL Frequency = 60/((1+0x0022)*2) (MHz) = 0.86MHz
//uint16_t dwClockDivisor = 0x0023;	//	35	Value of clock divisor, SCL Frequency = 60/((1+0x0023)*2) (MHz) = 0.83MHz
//uint16_t dwClockDivisor = 0x0024;	//	36	Value of clock divisor, SCL Frequency = 60/((1+0x0024)*2) (MHz) = 0.81MHz
//uint16_t dwClockDivisor = 0x0025;	//	37	Value of clock divisor, SCL Frequency = 60/((1+0x0025)*2) (MHz) = 0.79MHz
//uint16_t dwClockDivisor = 0x0026;	//	38	Value of clock divisor, SCL Frequency = 60/((1+0x0026)*2) (MHz) = 0.77MHz
//uint16_t dwClockDivisor = 0x0027;	//	39	Value of clock divisor, SCL Frequency = 60/((1+0x0027)*2) (MHz) = 0.75MHz

struct ftdi_context FTDI_PORTA;
struct ftdi_context FTDI_PORTB;
struct ftdi_context FTDI_PORTC;
struct ftdi_context FTDI_PORTD;

enum _SRecordDefinitions
	{
	SRECORD_RECORD_BUFF_SIZE	= 768,			// 768 should be plenty of space to read in an S-Record
	SRECORD_TYPE_OFFSET		= 1,			// Offsets and lengths of various fields in an S-Record record
	SRECORD_TYPE_LEN		= 1,
	SRECORD_COUNT_OFFSET		= 2,
	SRECORD_COUNT_LEN		= 2,
	SRECORD_ADDRESS_OFFSET		= 4,
	SRECORD_CHECKSUM_LEN		= 2,
	SRECORD_MAX_DATA_LEN		= 64,			// Maximum ascii hex length of the S-Record data field
	SRECORD_MAX_ADDRESS_LEN		= 8,			// Maximum ascii hex length of the S-Record address field
	SRECORD_ASCII_HEX_BYTE_LEN	= 2,			// Ascii hex length of a single byte
	SRECORD_START_CODE_OFFSET	= 0,			// Start code offset and value
	SRECORD_START_CODE		= 'S',
	};

enum SRecordErrors
	{
	SRECORD_OK			= 0, 			// Error code for success or no error.
	SRECORD_ERROR_FILE		= -1,			// Error code for reading from or writing to a file.
	SRECORD_ERROR_EOF		= -2,			// Error code for encountering end-of-file when reading from a file.
	SRECORD_ERROR_INVALID_RECORD	= -3, 			// Error code for error if an invalid record was read.
	SRECORD_ERROR_INVALID_ARGUMENTS	= -4, 			// Error code for error from invalid arguments passed to function.
	SRECORD_ERROR_NEWLINE		= -5,			// Error code for encountering a newline with no record when reading from a file.
	};

enum SRecordTypes
	{
	SRECORD_TYPE_S0		= 0,	// Header record. 16-bit address normally set to 0x0000 and header information is stored in the data field.
	SRECORD_TYPE_S1,		// Data record with 16-bit address
	SRECORD_TYPE_S2,		// Data record with 24-bit address
	SRECORD_TYPE_S3,		// Data record with 32-bit address
	SRECORD_TYPE_S4,		// Extension by LSI Logic, Inc. See their specification for more details.
	SRECORD_TYPE_S5,		// 16-bit address field contains the number of S1, S2, and S3 (all data) records transmitted. No data field.
	SRECORD_TYPE_S6,		// 24-bit address field contains the number of S1, S2, and S3 (all data) records transmitted. No data field.
	SRECORD_TYPE_S7,		// Termination record for S3 data records.
	SRECORD_TYPE_S8,		// Termination record for S2 data records.
	SRECORD_TYPE_S9,		// Termination record for S1 data records.
	};

typedef struct
	{
	uint32_t Address; 					// The address field. This can be 16, 24, or 32 bits depending on the record type.
	uint8_t Data[SRECORD_MAX_DATA_LEN / 2]; 		// The 8-bit array data field, which has a maximum size of 32 bytes.
	int16_t DataLength; 					// The number of bytes of data stored in this record.
	int16_t Type; 						// The Motorola S-Record type of this record (S0-S9).
	uint8_t Checksum; 					// The checksum of this record.
	} MotorolaSRecord;

int16_t 	Read_MotorolaSRecord(MotorolaSRecord *, FILE *);
uint8_t 	Checksum_MotorolaSRecord(const MotorolaSRecord *);

int16_t 	FTDIUwireFree(void);

int16_t 	FTDIUwireSetup(void);

void		FTDIUwireToggleCS(void);
void		FTDIUwireToggleSK(void);
void		FTDIUwireToggleDI(void);

void		FTDIUwireBitbangStartBitPlusOpcode_Bits3(uint8_t);

void		FTDIUwireBitbangAddress_Bits10(uint16_t);

void		FTDIUwireBitbangData_Bits16(uint16_t);

uint16_t 	FTDIUwireGetReadData_Bits16(void);

int16_t 	NonvolProgramAndVerify(void);
uint8_t 	NonvolBulkEraseAlgorithm(void);

uint8_t 	NonvolOneWordProgramAlgorithm(uint16_t, uint8_t, uint8_t);

void		NonvolWriteEnable_EWEN(void);
void		NonvolWriteDisable_EWDS(void);
void		NonvolBulkErase_ERASE(void);

void		NonvolOneWordProgram_WRITE(uint16_t, uint16_t);

void		NonvolOneWordRead_READ(uint16_t);

void		ClearNonvolWriteBuffer_Bits8(uint16_t, uint8_t);
void		ClearNonvolReadBuffer_Bits8(uint16_t, uint8_t);

void		SetFTDIUwireEnable(uint8_t);

void		BitbangWritePortB(unsigned char, unsigned char);

int main(int argc, char **argv)
	{
	MotorolaSRecord MotSRecord;

	FILE *MotorolaSRecordFile;

	FILE *BinaryFile;

	FILE *BinaryOutputFile;

	uint32_t BinaryFileLength;

	uint32_t RecordIndex;
	uint32_t RecordDataLength;
	uint32_t RecordAddress;
	uint32_t RecordExtendedAddress;
	uint8_t RecordData;
	uint16_t RecordType;

	uint32_t DataIndexMSB;
	uint32_t DataIndexLSB;

	uint16_t RegisterData_Bits16;

	uint8_t EraseStatus;

	uint16_t BufferTestIndex;

	uint32_t BufferTestIndexMSB;
	uint32_t BufferTestIndexLSB;
	uint8_t BufferTestFlag;

	uint16_t NonvolAddress_Bits8;
	uint16_t NonvolData_Bits16;

	if (argc < 2)
		{
		printf ("\n");
		printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");

		return FTDI_FAILURE;
		}

	switch (argv[1][0])
		{
		case 'h' :
		case 'H' :
		case '?' :
			printf("\n");
			printf("IFE_BRSW86_UWIRE HELP:\n");
			printf("ife_brsw86_uwire [ h|H|? ]                      ife_brsw66_uwire help\n");
//			printf("\n");
//			printf("ife_brsw86_uwire [ t|T ]                        toggle BRSW EEPROM (93AA86B) CS line\n");
//			printf("ife_brsw86_uwire [ k|K ]                        toggle BRSW EEPROM (93AA86B) SK line\n");
//			printf("ife_brsw86_uwire [ i|I ]                        toggle BRSW EEPROM (93AA86B) DI line\n");
			printf("\n");
			printf("ife_brsw86_uwire [ e|E ]                        erase BRSW EEPROM (93AA86B)\n");
			printf("ife_brsw86_uwire [ w|W ] address8 data16        write BRSW EEPROM (93AA86B)\n");
			printf("ife_brsw86_uwire [ s|S ] inputsrecfilename      program BRSW EEPROM (93AA86B) using SREC file\n");
			printf("ife_brsw86_uwire [ b|B ] inputbinfilename       program BRSW EEPROM (93AA86B) using binary file\n");
			printf("ife_brsw86_uwire [ r|R ]                        read BRSW EEPROM (93AA86B) page\n");
			printf("ife_brsw86_uwire [ c|C ] inputsrecfilename      compare BRSW EEPROM (93AA86B) to SREC file\n");
			printf("ife_brsw86_uwire [ m|M ] inputbinfilename       compare BRSW EEPROM (93AA86B) to binary file\n");
			printf("ife_brsw86_uwire [ f|F ] outputbinfilename      create BRSW EEPROM (93AA86B) binary file\n");
			printf("\n");
			return FTDI_SUCCESS;
			break;

		case 't' :
		case 'T' :
			printf("Info: Toggling Config EEPROM CS\n");

			do
				{
				FTDIStatus = FTDIUwireSetup();
				} while (FTDIStatus == SETUP_RETRY);

			if (FTDIStatus == SETUP_FAILURE)
				{
				return EXIT_FAILURE;
				}

			BitbangWritePortB(0x40, 0x40);

			for (;;)
				{
				FTDIUwireToggleCS();
				}

			BitbangWritePortB(0x00, 0x00);
			break;

		case 'k' :
		case 'K' :
			printf("Info: Toggling Config EEPROM SK\n");

			do
				{
				FTDIStatus = FTDIUwireSetup();
				} while (FTDIStatus == SETUP_RETRY);

			if (FTDIStatus == SETUP_FAILURE)
				{
				return EXIT_FAILURE;
				}

			BitbangWritePortB(0x40, 0x40);

			for (;;)
				{
				FTDIUwireToggleSK();
				}

			BitbangWritePortB(0x00, 0x00);
			break;

		case 'i' :
		case 'I' :
			printf("Info: Toggling Config EEPROM DI\n");

			do
				{
				FTDIStatus = FTDIUwireSetup();
				} while (FTDIStatus == SETUP_RETRY);

			if (FTDIStatus == SETUP_FAILURE)
				{
				return EXIT_FAILURE;
				}

			BitbangWritePortB(0x40, 0x40);
			for (;;)
				{
				FTDIUwireToggleDI();
				}

			BitbangWritePortB(0x00, 0x00);
			break;

		case 'e':
		case 'E':
			FileReadFlag = FILE_READ_NO;
			if (argc < 2)
				{
				printf ("\n");
				printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");
				return FTDI_FAILURE;
				}
			break;

		case 'w':
		case 'W':
			FileReadFlag = FILE_READ_NO;
			if (argc < 4)
				{
				printf ("\n");
				printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");
				return FTDI_FAILURE;
				}
			break;

		case 's':
		case 'S':
		case 'c':
		case 'C':
			FileReadFlag = FILE_READ_SREC;
			if (argc < 3)
				{
				printf ("\n");
				printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");
				return FTDI_FAILURE;
				}
			break;

		case 'b':
		case 'B':
		case 'm':
		case 'M':
			FileReadFlag = FILE_READ_BIN;
			if (argc < 3)
				{
				printf ("\n");
				printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");
				return FTDI_FAILURE;
				}
			break;

		case 'r':
		case 'R':
			FileReadFlag = FILE_READ_NO;
			if (argc < 2)
				{
				printf ("\n");
				printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");
				return FTDI_FAILURE;
				}
			break;

		case 'f' :
		case 'F' :
			FileReadFlag = FILE_READ_NO;
			if (argc < 3)
				{
				printf ("\n");
				printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");
				return FTDI_FAILURE;
				}
			break;

		default:
			printf ("\n");
			printf("Error: Refer to help screen for program details!\n\n");
			return FTDI_FAILURE;
			break;
		}

	printf ("\n");
	printf("  ##########################################################################\n");
	printf("  IIIII  FFFFF  EEEEE     BBBB   RRRR    SSSS  W   W     EEEEE  EEEEE  PPPP \n");
	printf("    I    F      E         B   B  R   R  S      W   W     E      E      P   P\n");
	printf("    I    F      E         B   B  RRRR   S      W   W     E      E      P   P\n");
	printf("    I    FFFFF  EEEEE     BBBB   RR      SSS   W   W     EEEEE  EEEEE  PPPP \n");
	printf("    I    F      E         B   B  R R        S  W W W     E      E      P    \n");
	printf("    I    F      E         B   B  R  R       S  WW WW     E      E      P    \n");
	printf("  IIIII  F      EEEEE     BBBB   R   R  SSSS   W   W     EEEEE  EEEEE  P    \n");
	printf("  ##########################################################################\n");

	switch (FileReadFlag)
		{
		case FILE_READ_SREC:
			memcpy (UwireSourceFilename, argv[2], strlen(argv[2]) + 1);

			MotorolaSRecordFile = fopen(UwireSourceFilename, "r");

			if (MotorolaSRecordFile == NULL)
				{
				printf("\n");
				printf("Error: Unable to open file!\n");
				printf("\n");
				return FTDI_FAILURE;
				break;
				}

			ClearNonvolWriteBuffer_Bits8(NONVOL_MEMORY_SIZE_IN_BYTES, 0xff);

			while (Read_MotorolaSRecord(&MotSRecord, MotorolaSRecordFile) == SRECORD_OK)
				{
				RecordType = MotSRecord.Type;
				RecordDataLength = MotSRecord.DataLength;
				RecordAddress = MotSRecord.Address;

				if ((RecordType == SRECORD_TYPE_S1) | (RecordType == SRECORD_TYPE_S2) | (RecordType == 						SRECORD_TYPE_S3))
					{
					for (RecordIndex = 0; RecordIndex < RecordDataLength; RecordIndex++)
						{
						RecordData = MotSRecord.Data[RecordIndex];
						RecordExtendedAddress = RecordAddress + RecordIndex;

						if (RecordExtendedAddress < NONVOL_MEMORY_SIZE_IN_BYTES)
							{
							NonvolWriteBuffer_Bits8[RecordExtendedAddress]  = RecordData; 
							}
						else
							{
							printf("\n");
							printf("Error: Maximum address exceeded.\n");
							printf("\n");
							return FTDI_FAILURE;
							}
						}
					}
				}

			fclose(MotorolaSRecordFile);
			break;

		case FILE_READ_BIN:
			memcpy (UwireSourceFilename, argv[2], strlen(argv[2]) + 1);

			BinaryFile = fopen(UwireSourceFilename, "r");

			if (BinaryFile == NULL)
				{
				printf("\n");
				printf("Error: Unable to open file!\n");
				printf("\n");
				return FTDI_FAILURE;
				break;
				}

			fseek(BinaryFile, 0, SEEK_END);

			BinaryFileLength = ftell(BinaryFile);

			if (BinaryFileLength > NONVOL_MEMORY_SIZE_IN_BYTES)
				{
				printf("\n");
				printf("Error: File size too big for buffer!\n");
				printf("\n");
				fclose(BinaryFile);
				return FTDI_FAILURE;
				break;
				}

			fseek(BinaryFile, 0, SEEK_SET);

			ClearNonvolWriteBuffer_Bits8(NONVOL_MEMORY_SIZE_IN_BYTES, 0xff);

			fread(NonvolWriteBuffer_Bits8, BinaryFileLength, 1, BinaryFile);

			fclose(BinaryFile);
			break;

		default:
			break;
		}

	do
		{
		FTDIStatus = FTDIUwireSetup();
		} while (FTDIStatus == SETUP_RETRY);

	if (FTDIStatus == SETUP_FAILURE)
		{
		return EXIT_FAILURE;
		}

	UwireEnableFlag = FTDI_UWIRE_DISABLE;
	SetFTDIUwireEnable (UwireEnableFlag);

	UwireEnableFlag = FTDI_UWIRE_ENABLE;
	SetFTDIUwireEnable (UwireEnableFlag);

	BitbangWritePortB(0x40, 0x40);

	switch (argv[1][0])
		{
		case 'e' :
		case 'E' :
			EraseStatus = NonvolBulkEraseAlgorithm();

			if (EraseStatus == UWIRE_FAILURE)
				{
				printf("Fail: Nonvolatile memory bulk erase command\n");
				return EXIT_FAILURE;
				}
			printf ("\n");
			printf ("\n");
			break;

		case 'w' :
		case 'W' :
			if (argc < 4)
				{
				printf("\n");
				printf("Error: Not enough parameters! Refer to help screen for program details.\n\n");
				return FTDI_FAILURE;
				}

			NonvolAddress_Bits8 = (unsigned int) strtoul(argv[2], NULL, 0);
			NonvolData_Bits16 = (unsigned int) strtoul(argv[3], NULL, 0);

			CountBytesToSend = 0;
			NonvolWriteEnable_EWEN();

			NonvolOneWordProgram_WRITE(NonvolAddress_Bits8, NonvolData_Bits16);
			ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

			usleep(WRITE_USLEEP_TEN_MILLISECONDS);

			CountBytesToSend = 0;
			NonvolWriteDisable_EWDS();
			ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

			printf ("\n");
			break;

		case 's' :
		case 'S' :
			CountBytesToSend = 0;
			NonvolWriteEnable_EWEN();
			ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

			usleep(EWEN_USLEEP_ONE_MILLISECONDS);

			NonvolProgramAndVerify();
			break;

		case 'b' :
		case 'B' :
			CountBytesToSend = 0;
			NonvolWriteEnable_EWEN();
			ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

			usleep(EWEN_USLEEP_ONE_MILLISECONDS);

			NonvolProgramAndVerify();
			break;

		case 'r' :
		case 'R' :
			printf ("\n");

			for (BufferTestIndex = 0; BufferTestIndex < NONVOL_MEMORY_SIZE_IN_LOCATIONS; BufferTestIndex++)
				{
				CountBytesToSend = 0;

				NonvolOneWordRead_READ(BufferTestIndex);

				ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

				usleep(READ_USLEEP_ONE_MILLISECONDS);

				ftdi_read_data(&FTDI_PORTA, InputBuffer, 16);

				RegisterData_Bits16 = FTDIUwireGetReadData_Bits16();

				NonvolReadBuffer_Bits8[(BufferTestIndex * 2)] = (uint8_t) ((RegisterData_Bits16 >> 8) & 0xff);
				NonvolReadBuffer_Bits8[(BufferTestIndex * 2) + 1] = (uint8_t) (RegisterData_Bits16 & 0xff);
				}

			for (DataIndexMSB = 0; DataIndexMSB < 16; DataIndexMSB++)
				{
				printf (" 0x%01X0 - ", (uint8_t) DataIndexMSB);
				printf ("0x%01XF: ", (uint8_t) DataIndexMSB);

				for (DataIndexLSB = 0; DataIndexLSB < 16; DataIndexLSB++)
					{
					NonvolDisplayAddress = ((DataIndexMSB * 16) + DataIndexLSB) * 2;

					RegisterData_Bits16 =	((NonvolReadBuffer_Bits8[NonvolDisplayAddress] << 8) & 0xff00) |
								(NonvolReadBuffer_Bits8[NonvolDisplayAddress + 1] & 0x00ff);

					printf ("0x%04X ", RegisterData_Bits16);
					}

				printf ("\n");
				}
			printf("\n");
			break;

		case 'c' :
		case 'C' :
			ClearNonvolReadBuffer_Bits8(NONVOL_MEMORY_SIZE_IN_BYTES, 0xff);

			for (BufferTestIndex = 0; BufferTestIndex < NONVOL_MEMORY_SIZE_IN_LOCATIONS; BufferTestIndex++)
				{
				CountBytesToSend = 0;

				NonvolOneWordRead_READ(BufferTestIndex);

				ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

				usleep(READ_USLEEP_ONE_MILLISECONDS);

				ftdi_read_data(&FTDI_PORTA, InputBuffer, 16);

				RegisterData_Bits16 = FTDIUwireGetReadData_Bits16();
				NonvolReadBuffer_Bits8[(BufferTestIndex * 2)] = (uint8_t) ((RegisterData_Bits16 >> 8) & 0xff);
				NonvolReadBuffer_Bits8[(BufferTestIndex * 2) + 1] = (uint8_t) (RegisterData_Bits16 & 0xff);
				}

			BufferTestFlag = 0;

			for (BufferTestIndex = 0; BufferTestIndex < NONVOL_MEMORY_SIZE_IN_BYTES; BufferTestIndex++)
				{
				if (NonvolReadBuffer_Bits8[BufferTestIndex] != NonvolWriteBuffer_Bits8[BufferTestIndex])
					{
					BufferTestFlag = 1;
					}
				}

			if (BufferTestFlag)
				{
				printf("\n");
				printf("Info: EEPROM memory compare FAILED\n");
				}
			else
				{
				printf("\n");
				printf("Info: EEPROM memory compare PASSED\n");
				}

			printf("\n");
			break;

		case 'm' :
		case 'M' :
			ClearNonvolReadBuffer_Bits8(NONVOL_MEMORY_SIZE_IN_BYTES, 0xff);

			for (BufferTestIndex = 0; BufferTestIndex < NONVOL_MEMORY_SIZE_IN_LOCATIONS; BufferTestIndex++)
				{
				CountBytesToSend = 0;

				NonvolOneWordRead_READ(BufferTestIndex);

				ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

				usleep(READ_USLEEP_ONE_MILLISECONDS);

				ftdi_read_data(&FTDI_PORTA, InputBuffer, 16);

				RegisterData_Bits16 = FTDIUwireGetReadData_Bits16();
				NonvolReadBuffer_Bits8[(BufferTestIndex * 2)] = (uint8_t) ((RegisterData_Bits16 >> 8) & 0xff);
				NonvolReadBuffer_Bits8[(BufferTestIndex * 2) + 1] = (uint8_t) (RegisterData_Bits16 & 0xff);
				}

			BufferTestFlag = 0;

			for (BufferTestIndex = 0; BufferTestIndex < NONVOL_MEMORY_SIZE_IN_BYTES; BufferTestIndex++)
				{
				if (NonvolReadBuffer_Bits8[BufferTestIndex] != NonvolWriteBuffer_Bits8[BufferTestIndex])
					{
					BufferTestFlag = 1;
					}
				}

			if (BufferTestFlag)
				{
				printf("\n");
				printf("Info: EEPROM memory compare FAILED\n");
				}
			else
				{
				printf("\n");
				printf("Info: EEPROM memory compare PASSED\n");
				}

			printf("\n");
			break;

		case 'f' :
		case 'F' :
			for (BufferTestIndex = 0; BufferTestIndex < NONVOL_MEMORY_SIZE_IN_LOCATIONS; BufferTestIndex++)
				{
				CountBytesToSend = 0;

				NonvolOneWordRead_READ(BufferTestIndex);

				ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

				usleep(READ_USLEEP_ONE_MILLISECONDS);

				ftdi_read_data(&FTDI_PORTA, InputBuffer, 16);

				RegisterData_Bits16 = FTDIUwireGetReadData_Bits16();

				NonvolReadBuffer_Bits8[(BufferTestIndex * 2)] = (uint8_t) ((RegisterData_Bits16 >> 8) & 0xff);
				NonvolReadBuffer_Bits8[(BufferTestIndex * 2) + 1] = (uint8_t) (RegisterData_Bits16 & 0xff);
				}

			memcpy (BinaryOutputFilename, argv[2], strlen(argv[2]) + 1);

			BinaryOutputFile = fopen(BinaryOutputFilename, "w");

			if (BinaryOutputFile)
				{
				fwrite(NonvolReadBuffer_Bits8, NONVOL_MEMORY_SIZE_IN_BYTES, 1, BinaryOutputFile);
				}
			else
				{
				printf("\n");
				printf("Error: Unable to open file!\n");
				printf("\n");
				return FTDI_FAILURE;
				break;
				}

			fclose(BinaryOutputFile);

			printf("\n");
			printf("Info: Binary file created!\n");
			printf("\n");

			return EXIT_SUCCESS;
			break;

		default :
			ftdi_usb_close(&FTDI_PORTA);
			ftdi_deinit(&FTDI_PORTA);
			break;
		}

	UwireEnableFlag = FTDI_UWIRE_DISABLE;
	SetFTDIUwireEnable (UwireEnableFlag);

	BitbangWritePortB(0x00, 0x00);

	//FTDIUwireFree();

	return EXIT_SUCCESS;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// SetFTDIUwireEnable (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void SetFTDIUwireEnable(uint8_t UwireEnable)
	{
	CountBytesToSend = 0;						//Clear output buffer

	if (UwireEnable == FTDI_UWIRE_ENABLE)
		{
		OutputBuffer[CountBytesToSend++] = 0x80;		//Command to set value / dir
		OutputBuffer[CountBytesToSend++] = 0x88;		//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
		}
	else
		{
		OutputBuffer[CountBytesToSend++] = 0x80;		//Command to set value / dir
		OutputBuffer[CountBytesToSend++] = 0x88;		//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
		}

	ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

	usleep(USLEEP_STATUS_MICROSECONDS);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// FTDIUwireToggleCS (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void FTDIUwireToggleCS()
	{
	CountBytesToSend = 0;						//Clear output buffer

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xa8;			//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0x88;			//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// FTDIUwireToggleSK (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void FTDIUwireToggleSK()
	{
	CountBytesToSend = 0;						//Clear output buffer

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0x89;			//1000 1001 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,SK
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0x88;			//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// FTDIUwireToggleDI (modified for ife) 
////////////////////////////////////////////////////////////////////////////////////////
void FTDIUwireToggleDI()
	{
	CountBytesToSend = 0;						//Clear output buffer

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0x8a;			//1000 1010 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,DI,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0x88;			//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);
	}

/////////////////////////////////////////////////////////////////////////////////////////
// FTDIUwireBitbangStartBitPlusOpcode_Bits3 (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void FTDIUwireBitbangStartBitPlusOpcode_Bits3(uint8_t UwireOpcodeToBeOutput)
	{
	uint8_t UwireDataOut;

	UwireDataOut = UwireOpcodeToBeOutput;

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xaa;			//1010 1010 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xab;			//1010 1011 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,SK
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xaa;			//1010 1010 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	switch (UwireOpcodeToBeOutput)
		{
		case UWIRE_OPCODE_EWEN :
		case UWIRE_OPCODE_EWDS :
			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa9;	//1010 1001 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,SK
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
		
			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa9;	//1010 1001 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,SK
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
			break;
		case UWIRE_OPCODE_WRITE :
			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa9;	//1010 1001 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,SK
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xaa;	//1010 1010 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xab;	//1010 1011 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,SK
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xaa;	//1010 1010 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
			break;
		case UWIRE_OPCODE_READ :
			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xaa;	//1010 1010 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xab;	//1010 1011 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,SK
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xaa;	//1010 1010 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa9;	//1010 1001 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,SK
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
			break;
		case UWIRE_OPCODE_ERASE :
			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xaa;	//1010 1010 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xab;	//1010 1011 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,SK
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xaa;	//1010 1010 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xaa;	//1010 1010 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xab;	//1010 1011 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,SK
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xaa;	//1010 1010 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,DI,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
			break;
		default:
			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa9;	//1010 1001 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,SK
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
		
			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa9;	//1010 1001 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,SK
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

			OutputBuffer[CountBytesToSend++] = 0x80;	//set value / dir
			OutputBuffer[CountBytesToSend++] = 0xa8;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
			OutputBuffer[CountBytesToSend++] = 0xfb;	//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
			break;
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////
// FTDIUwireBitbangAddress_Bits10 (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void FTDIUwireBitbangAddress_Bits10(uint16_t UwireAddressToBeOutput)
	{
	uint8_t DiBit;

	uint16_t UwireAddressOut;

	uint8_t IndexFTDI;

	UwireAddressOut = UwireAddressToBeOutput;

	for (IndexFTDI = 0; IndexFTDI < 10; IndexFTDI++)
		{
		DiBit = ((UwireAddressOut & 0x200) >> 8) & 0x02;	//get bit7 and move it to the bit1 position

		OutputBuffer[CountBytesToSend++] = 0x80;		//set value / dir
		OutputBuffer[CountBytesToSend++] = 0xa8 | DiBit;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

		OutputBuffer[CountBytesToSend++] = 0x80;		//set value / dir
		OutputBuffer[CountBytesToSend++] = 0xa9 | DiBit;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,SK
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

		OutputBuffer[CountBytesToSend++] = 0x80;		//set value / dir
		OutputBuffer[CountBytesToSend++] = 0xa8 | DiBit;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

		UwireAddressOut = UwireAddressOut << 1;
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////
// FTDIUwireBitbangData_Bits16 (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void FTDIUwireBitbangData_Bits16(uint16_t UwireDataToBeOutput)
	{
	uint8_t DiBit;

	uint16_t UwireDataOut;

	uint8_t IndexFTDI;

	ftdi_usb_purge_rx_buffer(&FTDI_PORTA);

	UwireDataOut = UwireDataToBeOutput;

	for (IndexFTDI = 0; IndexFTDI < 16; IndexFTDI++)
		{
		DiBit = ((UwireDataOut & 0x8000) >> 14) & 0x02;		//get bit15 and move it to the bit1 position

		OutputBuffer[CountBytesToSend++] = 0x80;		//set value / dir
		OutputBuffer[CountBytesToSend++] = 0xa8 | DiBit;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

		OutputBuffer[CountBytesToSend++] = 0x80;		//set value / dir
		OutputBuffer[CountBytesToSend++] = 0xa9 | DiBit;	//1010 1001 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,SK
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

		OutputBuffer[CountBytesToSend++] = 0x81;		//read low byte

		OutputBuffer[CountBytesToSend++] = 0x80;		//set value / dir
		OutputBuffer[CountBytesToSend++] = 0xa8 | DiBit;	//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

		UwireDataOut = UwireDataOut << 1;
		}

	OutputBuffer[CountBytesToSend++] = 0x87;			//Send answer back immediate
	}

/////////////////////////////////////////////////////////////////////////////////////////
// FTDIUwireGetReadByteData_Bits16
////////////////////////////////////////////////////////////////////////////////////////
uint16_t FTDIUwireGetReadData_Bits16()
	{
	uint16_t UwireDataIn;

	uint8_t FTDIReadBufferIndex;

	uint8_t FTDIReadBuffer[16];

	for(FTDIReadBufferIndex = 0; FTDIReadBufferIndex < 16; FTDIReadBufferIndex++)
		{
		FTDIReadBuffer[FTDIReadBufferIndex] = InputBuffer[FTDIReadBufferIndex] & 0x04;
		}

	UwireDataIn = 0x00;

	for(FTDIReadBufferIndex = 0; FTDIReadBufferIndex < 16; FTDIReadBufferIndex++)
		{
		UwireDataIn = (UwireDataIn << 1) | (FTDIReadBuffer[FTDIReadBufferIndex] ? 0x01 : 0x00);
		}

	return UwireDataIn;
	}

/****************************************************************************/
/*                                                                          */
/*  Function:         NonvolProgramAndVerify                                */
/*                                                                          */
/****************************************************************************/
int16_t NonvolProgramAndVerify()
	{
	uint8_t ProgramStatus;

	uint16_t ProgramAndVerifyError;

	uint16_t ProgramIndex;

	uint16_t PageProgramIndex;

	uint8_t PageProgramStatus;

	uint16_t VerifyIndex;

	uint16_t VerifyByteIndex;

	uint16_t VerifyData_Bits16;

	ProgramStatus = NonvolBulkEraseAlgorithm();

	if (ProgramStatus == UWIRE_FAILURE)
		{
		printf("\n");
		printf("Fail: Nonvolatile memory bulk erase command\n");
		return EXIT_FAILURE;
		}

	printf("\n");
	printf("Info: Nonvolatile memory programming  : .");
	fflush(stdout);

	ProgramAndVerifyError = 0;

	for (ProgramIndex = 0; ProgramIndex < NONVOL_MEMORY_SIZE_IN_LOCATIONS; ProgramIndex++)
		{
		PageProgramStatus = WORD_PROGRAM_NOT_NECESSARY;

		if (NonvolWriteBuffer_Bits8[(ProgramIndex * 2)] != 0xff)
			{
			PageProgramStatus = WORD_PROGRAM_NECESSARY;
			}

		if (NonvolWriteBuffer_Bits8[(ProgramIndex * 2) + 1] != 0xff)
			{
			PageProgramStatus = WORD_PROGRAM_NECESSARY;
			}

		if (PageProgramStatus == WORD_PROGRAM_NECESSARY)
			{
			ProgramStatus = NonvolOneWordProgramAlgorithm(	ProgramIndex,
									NonvolWriteBuffer_Bits8[(ProgramIndex * 2) + 1],
									NonvolWriteBuffer_Bits8[(ProgramIndex * 2)]);
			}

		if (ProgramIndex % DOT_PROGRESS_INTERVAL == 0)
			{
			printf(".");
			fflush(stdout);
			}

		if (ProgramStatus == UWIRE_FAILURE)
			{
			printf("\n");
			printf("Fail: Nonvolatile memory one word program algorithm\n");
			ProgramAndVerifyError += 1;
			return EXIT_FAILURE;
			}
		}

	CountBytesToSend = 0;
	NonvolWriteDisable_EWDS();
	ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

	usleep(EWEN_USLEEP_ONE_MILLISECONDS);

	printf("\n");
	printf("Info: Nonvolatile memory verifying    : .");
	fflush(stdout);

	usleep(READ_USLEEP_ONE_MILLISECONDS);

	CountBytesToSend = 0;
	NonvolOneWordRead_READ(0x00);
	ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);
	usleep(READ_USLEEP_ONE_MILLISECONDS);
	ftdi_read_data(&FTDI_PORTA, InputBuffer, 16);
	FTDIUwireGetReadData_Bits16();

	usleep(READ_USLEEP_ONE_MILLISECONDS);

	CountBytesToSend = 0;
	NonvolOneWordRead_READ(0x01);
	ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);
	usleep(READ_USLEEP_ONE_MILLISECONDS);
	ftdi_read_data(&FTDI_PORTA, InputBuffer, 16);
	FTDIUwireGetReadData_Bits16();

	ClearNonvolReadBuffer_Bits8(NONVOL_MEMORY_SIZE_IN_BYTES, 0xff);

	for (VerifyIndex = 0; VerifyIndex < NONVOL_MEMORY_SIZE_IN_LOCATIONS; VerifyIndex++)
		{
		CountBytesToSend = 0;

		NonvolOneWordRead_READ(VerifyIndex);

		ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

		usleep(READ_USLEEP_ONE_MILLISECONDS);

		ftdi_read_data(&FTDI_PORTA, InputBuffer, 16);

		VerifyData_Bits16 = FTDIUwireGetReadData_Bits16();

		NonvolReadBuffer_Bits8[(VerifyIndex * 2) + 1] = (uint8_t) ((VerifyData_Bits16 >> 8) & 0xff);
		NonvolReadBuffer_Bits8[(VerifyIndex * 2)] = (uint8_t) (VerifyData_Bits16 & 0xff);

		if (VerifyIndex % DOT_PROGRESS_INTERVAL == 0)
			{
			printf(".");
			fflush(stdout);
			}
		}

	for (VerifyByteIndex = 0; VerifyByteIndex < NONVOL_MEMORY_SIZE_IN_BYTES; VerifyByteIndex++)
		{
		if (NonvolWriteBuffer_Bits8[VerifyByteIndex] != NonvolReadBuffer_Bits8[VerifyByteIndex])
			{
			ProgramAndVerifyError += 1;
			printf("Fail: Write Buffer Address: %08X Write: %02X Read: %02X\n",
				VerifyByteIndex, NonvolWriteBuffer_Bits8[VerifyByteIndex],
				NonvolReadBuffer_Bits8[VerifyByteIndex]);
			}
		}

	printf("\n");

	if (ProgramAndVerifyError != 0)
		{
		printf("\n");
		printf("Fail: Overall programming error: %08x\n\n", ProgramAndVerifyError);
		return EXIT_FAILURE;
		}
	else
		{
		printf("\n");
		printf("Pass: Overall programming success!\n\n");
		}

	return EXIT_SUCCESS;
	}

//////////////////// HIGHER LEVEL FUNCTIONS///////////////////////////////////

/****************************************************************************/
/*                                                                          */
/*  Function:         NonvolBulkEraseAlgorithm                              */
/*                                                                          */
/****************************************************************************/
uint8_t NonvolBulkEraseAlgorithm()
	{
	printf("\n");
	printf("Info: Nonvolatile memory bulk erasing : .");
	fflush(stdout);

	CountBytesToSend = 0;
	NonvolWriteEnable_EWEN();
	ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

	NonvolBulkErase_ERASE();

	return UWIRE_SUCCESS;
	}

/****************************************************************************/
/*                                                                          */
/*  Function:         NonvolOneWordProgramAlgorithm                         */
/*                                                                          */
/****************************************************************************/
uint8_t NonvolOneWordProgramAlgorithm(uint16_t NonvolAddress, uint8_t NonvolDataUpperByte, uint8_t NonvolDataLowerByte)
	{
	uint8_t NonvolStatus;

	uint16_t NonvolData;

	CountBytesToSend = 0;
	NonvolWriteEnable_EWEN();

	NonvolData = ((NonvolDataUpperByte << 8) & 0xff00) | (NonvolDataLowerByte & 0x00ff);

	NonvolOneWordProgram_WRITE(NonvolAddress, NonvolData);
	ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

	usleep(WRITE_USLEEP_TEN_MILLISECONDS);

	return UWIRE_SUCCESS;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// NonvolOneWordProgram_WRITE (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void NonvolOneWordProgram_WRITE(uint16_t NonvolAddress, uint16_t NonvolData)
	{
	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xa8;			//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	FTDIUwireBitbangStartBitPlusOpcode_Bits3(UWIRE_OPCODE_WRITE);

	FTDIUwireBitbangAddress_Bits10(NonvolAddress);

	FTDIUwireBitbangData_Bits16(NonvolData);

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xa8;			//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0x88;			//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
	}

/////////////////////////////////////////////////////////////////////////////////////////
// NonvolOneWordRead_READ (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void NonvolOneWordRead_READ(uint16_t NonvolAddress)
	{
	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xa8;			//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	FTDIUwireBitbangStartBitPlusOpcode_Bits3(UWIRE_OPCODE_READ);

	FTDIUwireBitbangAddress_Bits10(NonvolAddress);

	FTDIUwireBitbangData_Bits16(0x00);

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xa8;			//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0x88;			//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
	}

/////////////////////////////////////////////////////////////////////////////////////////
// NonvolBulkErase_ERASE (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void NonvolBulkErase_ERASE()
	{
	uint16_t AddressIndex;

	for (AddressIndex = 0; AddressIndex < 0x0100; AddressIndex++)
		{
		CountBytesToSend = 0;					//Clear output buffer

		OutputBuffer[CountBytesToSend++] = 0x80;		//set value / dir
		OutputBuffer[CountBytesToSend++] = 0xa8;		//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

		FTDIUwireBitbangStartBitPlusOpcode_Bits3(UWIRE_OPCODE_ERASE);

		FTDIUwireBitbangAddress_Bits10(AddressIndex);

		OutputBuffer[CountBytesToSend++] = 0x80;		//set value / dir
		OutputBuffer[CountBytesToSend++] = 0xa8;		//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

		OutputBuffer[CountBytesToSend++] = 0x80;		//set value / dir
		OutputBuffer[CountBytesToSend++] = 0x88;		//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
		OutputBuffer[CountBytesToSend++] = 0xfb;		//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

		ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

		usleep(ERASE_USLEEP_TEN_MILLISECONDS);
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////
// NonvolWriteEnable_EWEN (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void NonvolWriteEnable_EWEN()
	{
	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xa8;			//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	FTDIUwireBitbangStartBitPlusOpcode_Bits3(UWIRE_OPCODE_EWEN);

	FTDIUwireBitbangAddress_Bits10(0x3ff);

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xa8;			//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0x88;			//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
	}

/////////////////////////////////////////////////////////////////////////////////////////
// NonvolWriteDisable_EWDS (modified for ife)
////////////////////////////////////////////////////////////////////////////////////////
void NonvolWriteDisable_EWDS()
	{
	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xa8;			//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	FTDIUwireBitbangStartBitPlusOpcode_Bits3(UWIRE_OPCODE_EWDS);

	FTDIUwireBitbangAddress_Bits10(0x000);

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0xa8;			//1010 1000 EZPCS,fpgaeecs,BRSWEECS,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGEECSA,BRSWEECS,NC | FPGACS,do,DI,SK

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0x88;			//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// MotorolaSHexRecord_Address_Lengths
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static int16_t MotorolaSRecord_Address_Lengths[] =
	{
	4, // S0
	4, // S1
	6, // S2
	8, // S3
	8, // S4
	4, // S5
	6, // S6
	8, // S7
	6, // S8
	4, // S9
	};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Read_MotorolaSRecord
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int16_t Read_MotorolaSRecord(MotorolaSRecord *SRecord, FILE *FileIn)
	{
	int8_t RecordBuffer[SRECORD_RECORD_BUFF_SIZE];

// A temporary buffer to hold ASCII hex encoded data, set to the maximum length we would ever need
	int8_t HexBuffer[SRECORD_MAX_ADDRESS_LEN + 1];

	int16_t AsciiAddressLength;
	int16_t AsciiDataLength;
	int16_t DataOffset;
	int16_t FieldDataCount;
	int16_t ReadIndex;
	
// Check our record pointer and file pointer
	if (SRecord == NULL || FileIn == NULL)
		{
		return SRECORD_ERROR_INVALID_ARGUMENTS;
		}

	if (fgets(RecordBuffer, SRECORD_RECORD_BUFF_SIZE, FileIn) == NULL)
		{
// In case we hit EOF, don't report a file error
		if (feof(FileIn) != 0)
			{
			return SRECORD_ERROR_EOF;
			}
		else
			{
			return SRECORD_ERROR_FILE;
			}
		}
// Null-terminate the string at the first sign of a \r or \n
	for (ReadIndex = 0; ReadIndex < (int16_t)strlen(RecordBuffer); ReadIndex++)
		{
		if (RecordBuffer[ReadIndex] == '\r' || RecordBuffer[ReadIndex] == '\n')
			{
			RecordBuffer[ReadIndex] = 0;
			break;
			}
		}

// Check if we hit a newline
	if (strlen(RecordBuffer) == 0)
		{
		return SRECORD_ERROR_NEWLINE;
		}

// Size check for type and count fields
	if (strlen(RecordBuffer) < SRECORD_TYPE_LEN + SRECORD_COUNT_LEN)
		{
		return SRECORD_ERROR_INVALID_RECORD;
		}

// Check for the S-Record start code at the beginning of every record
	if (RecordBuffer[SRECORD_START_CODE_OFFSET] != SRECORD_START_CODE)
		{
		return SRECORD_ERROR_INVALID_RECORD;
		}

// Copy the ASCII hex encoding of the type field into HexBuffer, convert it into a usable integer
	strncpy(HexBuffer, RecordBuffer + SRECORD_TYPE_OFFSET, SRECORD_TYPE_LEN);

	HexBuffer[SRECORD_TYPE_LEN] = 0;

	SRecord->Type = strtol(HexBuffer, (char **)NULL, 16);
	
// Copy the ASCII hex encoding of the count field into HexBuffer, convert it to a usable integer
	strncpy(HexBuffer, RecordBuffer + SRECORD_COUNT_OFFSET, SRECORD_COUNT_LEN);

	HexBuffer[SRECORD_COUNT_LEN] = 0;

	FieldDataCount = strtol(HexBuffer, (char **)NULL, 16);
	
// Check that our S-Record type is valid
	if (SRecord->Type < SRECORD_TYPE_S0 || SRecord->Type > SRECORD_TYPE_S9)
		{
		return SRECORD_ERROR_INVALID_RECORD;
		}

// Get the ASCII hex address length of this particular S-Record type
	AsciiAddressLength = MotorolaSRecord_Address_Lengths[SRecord->Type];
	
// Size check for address field
	if (strlen(RecordBuffer) < (uint16_t)(SRECORD_ADDRESS_OFFSET + AsciiAddressLength))
		{
		return SRECORD_ERROR_INVALID_RECORD;
		}

// Copy the ASCII hex encoding of the count field into hexBuff, convert it to a usable integer
	strncpy(HexBuffer, RecordBuffer + SRECORD_ADDRESS_OFFSET, AsciiAddressLength);

	HexBuffer[AsciiAddressLength] = 0;

	SRecord->Address = strtol(HexBuffer, (char **)NULL, 16);
	
// Compute the ASCII hex data length by subtracting the remaining field lengths from the S-Record 
// count field (times 2 to account for the number of characters used in ASCII hex encoding)
	AsciiDataLength = (FieldDataCount * 2) - AsciiAddressLength - SRECORD_CHECKSUM_LEN;

// Bailout if we get an invalid data length
	if (AsciiDataLength < 0 || AsciiDataLength > SRECORD_MAX_DATA_LEN)
		{
		return SRECORD_ERROR_INVALID_RECORD;
		}

// Size check for final data field and checksum field
	if (strlen(RecordBuffer) < (uint16_t)(SRECORD_ADDRESS_OFFSET + AsciiAddressLength + AsciiDataLength + SRECORD_CHECKSUM_LEN))
		{
		return SRECORD_ERROR_INVALID_RECORD;
		}

	DataOffset = SRECORD_ADDRESS_OFFSET + AsciiAddressLength;
	
// Loop through each ASCII hex byte of the data field, pull it out into HexBuffer,
// convert it and store the result in the data buffer of the S-Record
	for (ReadIndex = 0; ReadIndex < (AsciiDataLength / 2); ReadIndex++)
		{
// Times two i because every byte is represented by two ASCII hex characters
		strncpy(HexBuffer, RecordBuffer + DataOffset + (2 * ReadIndex), SRECORD_ASCII_HEX_BYTE_LEN);

		HexBuffer[SRECORD_ASCII_HEX_BYTE_LEN] = 0;

		SRecord->Data[ReadIndex] = strtol(HexBuffer, (char **)NULL, 16);
		}

// Real data len is divided by two because every byte is represented by two ASCII hex characters
	SRecord->DataLength = AsciiDataLength / 2;
	
// Copy out the checksum ASCII hex encoded byte, and convert it back to a usable integer
	strncpy(HexBuffer, RecordBuffer + DataOffset + AsciiDataLength, SRECORD_CHECKSUM_LEN);

	HexBuffer[SRECORD_CHECKSUM_LEN] = 0;

	SRecord->Checksum = strtol(HexBuffer, (char **)NULL, 16);

	if (SRecord->Checksum != Checksum_MotorolaSRecord(SRecord))
		{
		return SRECORD_ERROR_INVALID_RECORD;
		}

	return SRECORD_OK;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Checksum_MotorolaSRecord
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t Checksum_MotorolaSRecord(const MotorolaSRecord *SRecord)
	{
	uint8_t CalcChecksum;

	int16_t FieldDataCount;

	int16_t ChecksumIndex;
	
// Compute the record count, address and checksum lengths are halved because record count
// is the number of bytes left in the record, not the length of the ASCII hex representation
	FieldDataCount = (MotorolaSRecord_Address_Lengths[SRecord->Type] / 2) + SRecord->DataLength + (SRECORD_CHECKSUM_LEN / 2);

// Add the count, address, and data fields together
	CalcChecksum = FieldDataCount;

// Add each byte of the address individually
	CalcChecksum += (uint8_t)(SRecord->Address & 0x000000FF);
	CalcChecksum += (uint8_t)((SRecord->Address & 0x0000FF00) >> 8);
	CalcChecksum += (uint8_t)((SRecord->Address & 0x00FF0000) >> 16);
	CalcChecksum += (uint8_t)((SRecord->Address & 0xFF000000) >> 24);

	for (ChecksumIndex = 0; ChecksumIndex < SRecord->DataLength; ChecksumIndex++)
		{
		CalcChecksum += SRecord->Data[ChecksumIndex];
		}

// One's complement the checksum
	CalcChecksum = ~CalcChecksum;
	
	return CalcChecksum;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// ClearNonvolWriteBuffer_Bits8
////////////////////////////////////////////////////////////////////////////////////////
void ClearNonvolWriteBuffer_Bits8(uint16_t NonvolBufferSize, uint8_t NonvolBufferData_Bits8)
	{
	uint16_t NonvolBufferClearIndex;

	for (NonvolBufferClearIndex = 0; NonvolBufferClearIndex < NonvolBufferSize; NonvolBufferClearIndex++)
		{
		NonvolWriteBuffer_Bits8[NonvolBufferClearIndex] = NonvolBufferData_Bits8;
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////
// ClearNonvolReadBuffer_Bits8
////////////////////////////////////////////////////////////////////////////////////////
void ClearNonvolReadBuffer_Bits8(uint16_t NonvolBufferSize, uint8_t NonvolBufferData_Bits8)
	{
	uint16_t NonvolBufferClearIndex;

	for (NonvolBufferClearIndex = 0; NonvolBufferClearIndex < NonvolBufferSize; NonvolBufferClearIndex++)
		{
		NonvolReadBuffer_Bits8[NonvolBufferClearIndex] = NonvolBufferData_Bits8;
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////
// BitbangWritePortB
////////////////////////////////////////////////////////////////////////////////////////

void BitbangWritePortB(unsigned char BitbangDirection, unsigned char BitbangData)
	{
	int ReturnValue;

	unsigned char OutputBufferFTDI[8];

	ReturnValue = ftdi_set_bitmode(&FTDI_PORTB, BitbangDirection, BITMODE_BITBANG);
	if (ReturnValue < 0)
		{
		printf("Fail: Port B Set Bitmode error on ftdi\n");
		}

	OutputBufferFTDI[0] = BitbangData;

	ReturnValue = ftdi_write_data(&FTDI_PORTB, OutputBufferFTDI, 1);
	if (ReturnValue < 0)
		{
		printf("Fail: Port B Write Data error on ftdi\n");
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FTDIUwireFree
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int16_t FTDIUwireFree(void)
	{
	int ReturnValue;

	ReturnValue = ftdi_set_bitmode(&FTDI_PORTA, 0x00, BITMODE_RESET);   		//all pins are inputs
	if (ReturnValue < 0)
		{
		printf("Error: Port A bitmode error on IFE Line Card FTDI device\n");		//Error on MPSEE of FT2232H
		return EXIT_FAILURE;
		}

	ReturnValue = ftdi_set_bitmode(&FTDI_PORTB, 0x00, BITMODE_RESET);
	if (ReturnValue < 0)
		{
		printf("Error: Port B bitmode error on IFE Line Card FTDI device\n");		//Error on MPSEE of FT2232H
		return EXIT_FAILURE;
		}

/*	ReturnValue = ftdi_set_bitmode(&FTDI_PORTC, 0, BITMODE_RESET);
	if (ReturnValue < 0)
		{
		printf("Error: Port C bitmode error on IFE Line Card FTDI device\n");		//Error on MPSEE of FT2232H
		return EXIT_FAILURE;
		}

	ReturnValue = ftdi_set_bitmode(&FTDI_PORTD, 0x00, BITMODE_BITBANG);  		 //all pins are inputs
	if (ReturnValue < 0)
		{
		printf("Error: Port D bitmode error on IFE Line Card FTDI device\n");		//Error on MPSEE of FT2232H
		return EXIT_FAILURE;
		}*/

	return EXIT_SUCCESS;
	}

/////////////////////////////////////////////////////////////////////////////////////////
// FTDIUwireSetup
////////////////////////////////////////////////////////////////////////////////////////
int16_t FTDIUwireSetup(void)
	{
	int16_t FTDIStatus;

	uint16_t BufferIndex;

	uint8_t CommandEcho;

	CountBytesToSend = 0;							//Clear output buffer

// INTERFACE A
	if (ftdi_init(&FTDI_PORTA) < 0)
		{
		printf("\n");
		fprintf(stderr, "Error: Port B FTDI init failed\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	ftdi_set_interface(&FTDI_PORTA, INTERFACE_A);
	if ( (FTDIStatus = ftdi_usb_open(&FTDI_PORTA, FTDI_MINI_VENDOR_ID, FTDI_MINI_PRODUCT_ID)) < 0 )
		{
		printf("\n");
		fprintf(stderr, "Error: Port A unable to open FTDI device %d (%s)\n", FTDIStatus, ftdi_get_error_string(&FTDI_PORTA) );
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_usb_reset(&FTDI_PORTA);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port A reset error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_usb_purge_rx_buffer(&FTDI_PORTA);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port A purge rx error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_write_data_set_chunksize(&FTDI_PORTA, 1024);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port A write chunksize error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_read_data_set_chunksize(&FTDI_PORTA, 1024);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port A read chunksize error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_set_event_char(&FTDI_PORTA, 0, 0);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port A event char error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}
	FTDIStatus = ftdi_set_error_char(&FTDI_PORTA, 0, 0);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port A error char error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_set_latency_timer(&FTDI_PORTA, 1);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port A latency timer error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTA, 0x0, BITMODE_MPSSE);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port A bitmode error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	OutputBuffer[CountBytesToSend++] = 0xAA;			//Add bad command 'AA'

	FTDIStatus = ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

	BufferIndex = 0;

	do
		{
		FTDIStatus = ftdi_read_data(&FTDI_PORTA, InputBuffer, 2);
		BufferIndex += 1;
		} while ((FTDIStatus == 0) && (BufferIndex < 256));

	if (BufferIndex == 256)
		{
		return SETUP_RETRY;
		}

	CommandEcho = 0;

	for (BufferIndex = 0; BufferIndex < 256; BufferIndex++)		//Check if bad command and echo command received
		{
		if ((InputBuffer[BufferIndex] == 0xFA) && (InputBuffer[BufferIndex + 1] == 0xAA))
			{
			CommandEcho = 1;
			break;
			}
		}

	if (CommandEcho == 0)
		{
		return SETUP_RETRY;
		}

	CountBytesToSend = 0;						//Clear output buffer

	OutputBuffer[CountBytesToSend++] = 0x8A;			//Ensure disable clock divide by 5 for 60Mhz master clock
	OutputBuffer[CountBytesToSend++] = 0x97;			//Ensure turn off adaptive clocking
	OutputBuffer[CountBytesToSend++] = 0x8D;			//Disable 3 phase data clock

	FTDIStatus = ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

	CountBytesToSend = 0;						//Clear output buffer

	OutputBuffer[CountBytesToSend++] = 0x80;			//set value / dir
	OutputBuffer[CountBytesToSend++] = 0x88;			//1000 1000 EZPCS,fpgaeecs,brsweecs,nc | FPGACS,do,di,sk
	OutputBuffer[CountBytesToSend++] = 0xfb;			//1111 1011 EZPCS,FPGAEECS,BRSWEECS,NC | FPGACS,do,DI,SK

	OutputBuffer[CountBytesToSend++] = 0x86;				//Command to set clock divisor
	OutputBuffer[CountBytesToSend++] = dwClockDivisor & 0xFF;		//Set 0xValueL of clock divisor
	OutputBuffer[CountBytesToSend++] = (dwClockDivisor >> 8) & 0xFF;	//Set 0xValueH of clock divisor

	FTDIStatus = ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

	CountBytesToSend = 0;						//Clear output buffer

	OutputBuffer[CountBytesToSend++] = 0x85;			//Command to turn off loop back of TDI/TDO connection

	FTDIStatus = ftdi_write_data(&FTDI_PORTA, OutputBuffer, CountBytesToSend);

	CountBytesToSend = 0;						//Clear output buffer


// INTERFACE B
	if (ftdi_init(&FTDI_PORTB) < 0)
		{
		printf("\n");
		fprintf(stderr, "Error: Port B FTDI init failed\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	ftdi_set_interface(&FTDI_PORTB, INTERFACE_B);
	if ( (FTDIStatus = ftdi_usb_open(&FTDI_PORTB, FTDI_MINI_VENDOR_ID, FTDI_MINI_PRODUCT_ID)) < 0 )
		{
		printf("\n");
		fprintf(stderr, "Error: Port B unable to open FTDI device %d (%s)\n", FTDIStatus, ftdi_get_error_string(&FTDI_PORTB) );
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_usb_reset(&FTDI_PORTB);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B reset error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTB, 0, BITMODE_BITBANG);   //all pins are inputs
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port B bitmode error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}
/*
// INTERFACE C
	if (ftdi_init(&FTDI_PORTC) < 0)
		{
		printf("\n");
		fprintf(stderr, "Error: Port C FTDI init failed\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	ftdi_set_interface(&FTDI_PORTC, INTERFACE_C);
	if ( (FTDIStatus = ftdi_usb_open(&FTDI_PORTC, FTDI_MINI_VENDOR_ID, FTDI_MINI_PRODUCT_ID)) < 0 )
		{
		printf("\n");
		fprintf(stderr, "Error: Port C unable to open FTDI device %d (%s)\n", FTDIStatus, ftdi_get_error_string(&FTDI_PORTC) );
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_usb_reset(&FTDI_PORTC);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port C reset error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTC, 0x0, BITMODE_BITBANG);   //all pins are inputs
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port C bitmode error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

// INTERFACE D
	if (ftdi_init(&FTDI_PORTD) < 0)
		{
		printf("\n");
		fprintf(stderr, "Error: Port D FTDI init failed\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	ftdi_set_interface(&FTDI_PORTD, INTERFACE_D);
	if ( (FTDIStatus = ftdi_usb_open(&FTDI_PORTD, FTDI_MINI_VENDOR_ID, FTDI_MINI_PRODUCT_ID)) < 0 )
		{
		printf("\n");
		fprintf(stderr, "Error: Port D unable to open FTDI device %d (%s)\n", FTDIStatus, ftdi_get_error_string(&FTDI_PORTD) );
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_usb_reset(&FTDI_PORTD);
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port D reset error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}

	FTDIStatus = ftdi_set_bitmode(&FTDI_PORTD, 0x0, BITMODE_BITBANG);   //all pins are inputs
	if (FTDIStatus < 0)
		{
		printf("\n");
		printf("Error: Port D bitmode error on DSU-D4 FTDI device\n");
		printf("\n");
		return SETUP_FAILURE;
		}
*/
	return SETUP_SUCCESS;
	}

